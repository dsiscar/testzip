#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class WVMKtor_client_coreHttpClient, WVMWeroModuleHelperIdentifier, WVMKotlinEnumCompanion, WVMKotlinEnum<E>, WVMKotlinArray<T>, WVMKtor_client_loggingLogLevel, WVMFeatureHttpClientConfig, WVMHttpRequestHeadersPluginFactory, WVMStringResources, WVMStringRes, WVMResourcesStringDesc, WVMMainUiState, WVMMainUiStateLoading, WVMMainUiStateSuccess, WVMViewmodelViewModel, WVMFlowCoreStateFlow<T>, WVMFactStateUiModel, WVMFactStateUiModelError, WVMFactStateUiModelLoading, WVMFactStateUiModelSuccess, WVMNetworkViewModelMapper, WVMDomain_factGetFactUseCase, WVMKoin_coreModule, WVMKtor_client_coreHttpClientEngineConfig, WVMKtor_client_coreHttpClientConfig<T>, WVMKtor_eventsEvents, WVMKtor_client_coreHttpReceivePipeline, WVMKtor_client_coreHttpRequestPipeline, WVMKtor_client_coreHttpResponsePipeline, WVMKtor_client_coreHttpSendPipeline, WVMKtor_utilsAttributeKey<T>, WVMKotlinCancellationException, WVMKotlinThrowable, WVMKotlinx_coroutines_coreCoroutineDispatcher, WVMDomain_factGetFactUseCaseMappers, WVMDomain_factRetrieveFactUseCaseMappers, WVMCore_commonsDispatchers, WVMKoin_coreKoinDefinition<R>, WVMKoin_coreScope, WVMKoin_coreParametersHolder, WVMKoin_coreInstanceFactory<T>, WVMKoin_coreSingleInstanceFactory<T>, WVMKoin_coreScopeDSL, WVMKtor_client_coreHttpRequestData, WVMKtor_client_coreHttpResponseData, WVMKtor_client_coreProxyConfig, WVMKtor_eventsEventDefinition<T>, WVMKtor_utilsPipelinePhase, WVMKtor_utilsPipeline<TSubject, TContext>, WVMKtor_client_coreHttpReceivePipelinePhases, WVMKtor_client_coreHttpResponse, WVMKotlinUnit, WVMKtor_client_coreHttpRequestPipelinePhases, WVMKtor_client_coreHttpRequestBuilder, WVMKtor_client_coreHttpResponsePipelinePhases, WVMKtor_client_coreHttpResponseContainer, WVMKtor_client_coreHttpClientCall, WVMKtor_client_coreHttpSendPipelinePhases, WVMKotlinException, WVMKotlinRuntimeException, WVMKotlinIllegalStateException, WVMKotlinAbstractCoroutineContextElement, WVMKotlinx_coroutines_coreCoroutineDispatcherKey, WVMData_factFactRepositoryStateModel, WVMKoin_coreLockable, WVMKoin_coreKoin, WVMKotlinLazyThreadSafetyMode, WVMStately_concurrencyThreadLocalRef<T>, WVMKoin_coreLogger, WVMKoin_coreBeanDefinition<T>, WVMKoin_coreInstanceFactoryCompanion, WVMKoin_coreInstanceContext, WVMKtor_httpUrl, WVMKtor_httpHttpMethod, WVMKtor_httpOutgoingContent, WVMKtor_httpHttpStatusCode, WVMKtor_utilsGMTDate, WVMKtor_httpHttpProtocolVersion, WVMKtor_httpHeadersBuilder, WVMKtor_client_coreHttpRequestBuilderCompanion, WVMKtor_httpURLBuilder, WVMKtor_utilsTypeInfo, WVMKtor_client_coreHttpClientCallCompanion, WVMKotlinAbstractCoroutineContextKey<B, E>, WVMKoin_coreExtensionManager, WVMKoin_coreInstanceRegistry, WVMKoin_corePropertyRegistry, WVMKoin_coreScopeRegistry, WVMKoin_coreLevel, WVMKoin_coreKind, WVMKoin_coreCallbacks<T>, WVMKtor_httpUrlCompanion, WVMKtor_httpURLProtocol, WVMKtor_httpHttpMethodCompanion, WVMKtor_httpContentType, WVMKtor_httpHttpStatusCodeCompanion, WVMKtor_utilsGMTDateCompanion, WVMKtor_utilsWeekDay, WVMKtor_utilsMonth, WVMKtor_httpHttpProtocolVersionCompanion, WVMKtor_ioMemory, WVMKtor_ioChunkBuffer, WVMKtor_ioBuffer, WVMKotlinByteArray, WVMKtor_ioByteReadPacket, WVMKtor_utilsStringValuesBuilderImpl, WVMKtor_httpURLBuilderCompanion, WVMKoin_coreScopeRegistryCompanion, WVMKtor_httpURLProtocolCompanion, WVMKtor_httpHeaderValueParam, WVMKtor_httpHeaderValueWithParametersCompanion, WVMKtor_httpHeaderValueWithParameters, WVMKtor_httpContentTypeCompanion, WVMKtor_utilsWeekDayCompanion, WVMKtor_utilsMonthCompanion, WVMKtor_ioMemoryCompanion, WVMKtor_ioBufferCompanion, WVMKtor_ioChunkBufferCompanion, WVMKotlinByteIterator, WVMKtor_ioInputCompanion, WVMKtor_ioInput, WVMKtor_ioByteReadPacketCompanion, WVMKotlinKTypeProjection, WVMKotlinKVariance, WVMKotlinKTypeProjectionCompanion;

@protocol WVMKotlinComparable, WVMHttpRequestHeadersProvider, WVMKtor_client_coreClientPlugin, WVMKotlinAutoCloseable, WVMKotlinx_coroutines_coreCoroutineScope, WVMKotlinx_coroutines_coreJob, WVMDomain_factGetFactUseCaseStateModel, WVMKotlinCoroutineContext, WVMKtor_ioCloseable, WVMKtor_client_coreHttpClientEngine, WVMKtor_client_coreHttpClientEngineCapability, WVMKtor_utilsAttributes, WVMKotlinIterator, WVMKtor_client_coreHttpClientPlugin, WVMKotlinx_coroutines_coreChildHandle, WVMKotlinx_coroutines_coreChildJob, WVMKotlinx_coroutines_coreDisposableHandle, WVMKotlinSequence, WVMKotlinx_coroutines_coreSelectClause0, WVMKotlinCoroutineContextKey, WVMKotlinCoroutineContextElement, WVMKotlinx_coroutines_coreFlowCollector, WVMKotlinx_coroutines_coreFlow, WVMKotlinx_coroutines_coreSharedFlow, WVMKotlinx_coroutines_coreStateFlow, WVMEntity_factFactEntity, WVMData_factFactRepository, WVMKoin_coreQualifier, WVMKotlinSuspendFunction2, WVMKotlinx_coroutines_coreParentJob, WVMKotlinx_coroutines_coreSelectInstance, WVMKotlinx_coroutines_coreSelectClause, WVMKotlinContinuation, WVMKotlinContinuationInterceptor, WVMKotlinx_coroutines_coreRunnable, WVMEntity_factFactEntityState, WVMKotlinKClass, WVMKotlinLazy, WVMKoin_coreScopeCallback, WVMKtor_httpHeaders, WVMKotlinFunction, WVMKtor_httpHttpMessage, WVMKtor_ioByteReadChannel, WVMKtor_httpHttpMessageBuilder, WVMKtor_client_coreHttpRequest, WVMKoin_coreKoinScopeComponent, WVMKotlinKDeclarationContainer, WVMKotlinKAnnotatedElement, WVMKotlinKClassifier, WVMKtor_httpParameters, WVMKotlinMapEntry, WVMKtor_utilsStringValues, WVMKtor_ioReadSession, WVMKotlinSuspendFunction1, WVMKotlinAppendable, WVMKtor_utilsStringValuesBuilder, WVMKtor_httpParametersBuilder, WVMKotlinKType, WVMKoin_coreKoinComponent, WVMKoin_coreKoinExtension, WVMKtor_ioObjectPool;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface WVMBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface WVMBase (WVMBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface WVMMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface WVMMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorWVMKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface WVMNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface WVMByte : WVMNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface WVMUByte : WVMNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface WVMShort : WVMNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface WVMUShort : WVMNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface WVMInt : WVMNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface WVMUInt : WVMNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface WVMLong : WVMNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface WVMULong : WVMNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface WVMFloat : WVMNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface WVMDouble : WVMNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface WVMBoolean : WVMNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("WeroModuleHelper")))
@interface WVMWeroModuleHelper : WVMBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)doInitKoinAppHttpClient:(WVMKtor_client_coreHttpClient *)httpClient __attribute__((swift_name("doInitKoinApp(httpClient:)")));
- (id _Nullable)provideIdentifier:(WVMWeroModuleHelperIdentifier *)identifier __attribute__((swift_name("provide(identifier:)")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol WVMKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface WVMKotlinEnum<E> : WVMBase <WVMKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) WVMKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("WeroModuleHelper.Identifier")))
@interface WVMWeroModuleHelperIdentifier : WVMKotlinEnum<WVMWeroModuleHelperIdentifier *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) WVMWeroModuleHelperIdentifier *firstviewmodeldelegate __attribute__((swift_name("firstviewmodeldelegate")));
@property (class, readonly) WVMWeroModuleHelperIdentifier *secondviewmodeldelegate __attribute__((swift_name("secondviewmodeldelegate")));
+ (WVMKotlinArray<WVMWeroModuleHelperIdentifier *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<WVMWeroModuleHelperIdentifier *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FeatureHttpClientConfig")))
@interface WVMFeatureHttpClientConfig : WVMBase
- (instancetype)initWithTimeoutMillis:(int64_t)timeoutMillis developmentMode:(BOOL)developmentMode logLevel:(WVMKtor_client_loggingLogLevel *)logLevel __attribute__((swift_name("init(timeoutMillis:developmentMode:logLevel:)"))) __attribute__((objc_designated_initializer));
- (WVMFeatureHttpClientConfig *)doCopyTimeoutMillis:(int64_t)timeoutMillis developmentMode:(BOOL)developmentMode logLevel:(WVMKtor_client_loggingLogLevel *)logLevel __attribute__((swift_name("doCopy(timeoutMillis:developmentMode:logLevel:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@property (readonly) WVMKtor_client_loggingLogLevel *logLevel __attribute__((swift_name("logLevel")));
@property (readonly) int64_t timeoutMillis __attribute__((swift_name("timeoutMillis")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FeatureHttpClientFactory")))
@interface WVMFeatureHttpClientFactory : WVMBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (WVMKtor_client_coreHttpClient *)makeConfig:(WVMFeatureHttpClientConfig *)config headersFactory:(WVMHttpRequestHeadersPluginFactory *)headersFactory __attribute__((swift_name("make(config:headersFactory:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("HttpRequestHeadersPluginFactory")))
@interface WVMHttpRequestHeadersPluginFactory : WVMBase
- (instancetype)initWithHeadersProvider:(id<WVMHttpRequestHeadersProvider>)headersProvider __attribute__((swift_name("init(headersProvider:)"))) __attribute__((objc_designated_initializer));
- (id<WVMKtor_client_coreClientPlugin>)make __attribute__((swift_name("make()")));
@end

__attribute__((swift_name("HttpRequestHeadersProvider")))
@protocol WVMHttpRequestHeadersProvider
@required
- (NSDictionary<NSString *, NSString *> *)provide __attribute__((swift_name("provide()")));
@end


/**
 * @note annotations
 *   androidx.compose.runtime.Immutable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Resources")))
@interface WVMResources : WVMBase
- (instancetype)initWithLocale:(NSString *)locale __attribute__((swift_name("init(locale:)"))) __attribute__((objc_designated_initializer));
- (WVMStringResources *)getString __attribute__((swift_name("getString()")));
@property (readonly) NSString *locale __attribute__((swift_name("locale")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StringRes")))
@interface WVMStringRes : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)stringRes __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMStringRes *shared __attribute__((swift_name("shared")));
@property (readonly) WVMResourcesStringDesc *transverseAppUpdateLater __attribute__((swift_name("transverseAppUpdateLater")));
@property (readonly) WVMResourcesStringDesc *transverseAutorisationBoutonReglages __attribute__((swift_name("transverseAutorisationBoutonReglages")));
@property (readonly) WVMResourcesStringDesc *transverseBoutonAnnuler __attribute__((swift_name("transverseBoutonAnnuler")));
@property (readonly) WVMResourcesStringDesc *transverseBoutonContinuer __attribute__((swift_name("transverseBoutonContinuer")));
@property (readonly) WVMResourcesStringDesc *transverseBoutonFermer __attribute__((swift_name("transverseBoutonFermer")));
@property (readonly) WVMResourcesStringDesc *transverseBoutonValider __attribute__((swift_name("transverseBoutonValider")));
@property (readonly) WVMResourcesStringDesc *transverseContacterAgence __attribute__((swift_name("transverseContacterAgence")));
@property (readonly) WVMResourcesStringDesc *transverseContactsAutorisationIos __attribute__((swift_name("transverseContactsAutorisationIos")));
@property (readonly) WVMResourcesStringDesc *transverseContactsAutorisationPopupTexte __attribute__((swift_name("transverseContactsAutorisationPopupTexte")));
@property (readonly) WVMResourcesStringDesc *transverseContactsAutorisationPopupTexte2 __attribute__((swift_name("transverseContactsAutorisationPopupTexte2")));
@property (readonly) WVMResourcesStringDesc *transverseContactsAutorisationPopupTexteIos __attribute__((swift_name("transverseContactsAutorisationPopupTexteIos")));
@property (readonly) WVMResourcesStringDesc *transverseContactsAutorisationPopupTitre __attribute__((swift_name("transverseContactsAutorisationPopupTitre")));
@property (readonly) WVMResourcesStringDesc *transverseSuivant __attribute__((swift_name("transverseSuivant")));
@property (readonly) WVMResourcesStringDesc *weroP2pContactProxyEligibleOkMessage __attribute__((swift_name("weroP2pContactProxyEligibleOkMessage")));
@property (readonly) WVMResourcesStringDesc *weroP2pContactProxyEligibleOkTitre __attribute__((swift_name("weroP2pContactProxyEligibleOkTitre")));
@property (readonly) WVMResourcesStringDesc *weroP2pContactsAccesBouton __attribute__((swift_name("weroP2pContactsAccesBouton")));
@property (readonly) WVMResourcesStringDesc *weroP2pContactsBarre __attribute__((swift_name("weroP2pContactsBarre")));
@property (readonly) WVMResourcesStringDesc *weroP2pContactsListe __attribute__((swift_name("weroP2pContactsListe")));
@property (readonly) WVMResourcesStringDesc *weroP2pContactsListeVide __attribute__((swift_name("weroP2pContactsListeVide")));
@property (readonly) WVMResourcesStringDesc *weroP2pContactsPlusieursCoordonneesLibelle __attribute__((swift_name("weroP2pContactsPlusieursCoordonneesLibelle")));
@property (readonly) WVMResourcesStringDesc *weroP2pContactsPlusieursCoordonneesTitre __attribute__((swift_name("weroP2pContactsPlusieursCoordonneesTitre")));
@property (readonly) WVMResourcesStringDesc *weroP2pContactsSaisirEmail __attribute__((swift_name("weroP2pContactsSaisirEmail")));
@property (readonly) WVMResourcesStringDesc *weroP2pContactsSaisirNumero __attribute__((swift_name("weroP2pContactsSaisirNumero")));
@property (readonly) WVMResourcesStringDesc *weroP2pContactsSaisirNumeroInformation __attribute__((swift_name("weroP2pContactsSaisirNumeroInformation")));
@property (readonly) WVMResourcesStringDesc *weroP2pContactsSaisirNumeroListePaysTitre __attribute__((swift_name("weroP2pContactsSaisirNumeroListePaysTitre")));
@property (readonly) WVMResourcesStringDesc *weroP2pContactsSaisirNumeroNomChamp __attribute__((swift_name("weroP2pContactsSaisirNumeroNomChamp")));
@property (readonly) WVMResourcesStringDesc *weroP2pContactsSaisirNumeroTitre __attribute__((swift_name("weroP2pContactsSaisirNumeroTitre")));
@property (readonly) WVMResourcesStringDesc *weroP2pContactsTitre __attribute__((swift_name("weroP2pContactsTitre")));
@property (readonly) WVMResourcesStringDesc *weroP2pEnrolementEligibiliteCondition1 __attribute__((swift_name("weroP2pEnrolementEligibiliteCondition1")));
@property (readonly) WVMResourcesStringDesc *weroP2pEnrolementEligibiliteCondition2 __attribute__((swift_name("weroP2pEnrolementEligibiliteCondition2")));
@property (readonly) WVMResourcesStringDesc *weroP2pEnrolementEligibiliteCondition3 __attribute__((swift_name("weroP2pEnrolementEligibiliteCondition3")));
@property (readonly) WVMResourcesStringDesc *weroP2pEnrolementEligibiliteCondition4 __attribute__((swift_name("weroP2pEnrolementEligibiliteCondition4")));
@property (readonly) WVMResourcesStringDesc *weroP2pEnrolementEligibiliteMessage1 __attribute__((swift_name("weroP2pEnrolementEligibiliteMessage1")));
@property (readonly) WVMResourcesStringDesc *weroP2pEnrolementEligibiliteMessage2 __attribute__((swift_name("weroP2pEnrolementEligibiliteMessage2")));
@property (readonly) WVMResourcesStringDesc *weroP2pEnrolementEligibiliteTitre __attribute__((swift_name("weroP2pEnrolementEligibiliteTitre")));
@property (readonly) WVMResourcesStringDesc *weroP2pEnrolementTutoBoutonActiver __attribute__((swift_name("weroP2pEnrolementTutoBoutonActiver")));
@property (readonly) WVMResourcesStringDesc *weroP2pEnrolementTutoEcran1Texte __attribute__((swift_name("weroP2pEnrolementTutoEcran1Texte")));
@property (readonly) WVMResourcesStringDesc *weroP2pEnrolementTutoEcran1Titre __attribute__((swift_name("weroP2pEnrolementTutoEcran1Titre")));
@property (readonly) WVMResourcesStringDesc *weroP2pEnrolementTutoEcran2Texte1 __attribute__((swift_name("weroP2pEnrolementTutoEcran2Texte1")));
@property (readonly) WVMResourcesStringDesc *weroP2pEnrolementTutoEcran2Texte2 __attribute__((swift_name("weroP2pEnrolementTutoEcran2Texte2")));
@property (readonly) WVMResourcesStringDesc *weroP2pEnrolementTutoEcran2Titre __attribute__((swift_name("weroP2pEnrolementTutoEcran2Titre")));
@property (readonly) WVMResourcesStringDesc *weroP2pEnrolementTutoEcran3Texte1 __attribute__((swift_name("weroP2pEnrolementTutoEcran3Texte1")));
@property (readonly) WVMResourcesStringDesc *weroP2pEnrolementTutoEcran3Texte2 __attribute__((swift_name("weroP2pEnrolementTutoEcran3Texte2")));
@property (readonly) WVMResourcesStringDesc *weroP2pEnrolementTutoEcran3Titre __attribute__((swift_name("weroP2pEnrolementTutoEcran3Titre")));
@property (readonly) WVMResourcesStringDesc *weroP2pMontantPlafondBamKo __attribute__((swift_name("weroP2pMontantPlafondBamKo")));
@property (readonly) WVMResourcesStringDesc *weroP2pMontantPlafondBamKoZero __attribute__((swift_name("weroP2pMontantPlafondBamKoZero")));
@property (readonly) WVMResourcesStringDesc *weroP2pMontantPlafondWeroKo __attribute__((swift_name("weroP2pMontantPlafondWeroKo")));
@property (readonly) WVMResourcesStringDesc *weroP2pMontantTitre __attribute__((swift_name("weroP2pMontantTitre")));
@end


/**
 * @note annotations
 *   androidx.compose.runtime.Immutable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StringResources")))
@interface WVMStringResources : WVMBase
- (instancetype)initWithTransverseAutorisationBoutonReglages:(NSString *)transverseAutorisationBoutonReglages transverseContactsAutorisationIos:(NSString *)transverseContactsAutorisationIos transverseContactsAutorisationPopupTitre:(NSString *)transverseContactsAutorisationPopupTitre transverseContactsAutorisationPopupTexteIos:(NSString *)transverseContactsAutorisationPopupTexteIos transverseContactsAutorisationPopupTexte:(NSString *)transverseContactsAutorisationPopupTexte transverseContactsAutorisationPopupTexte2:(NSString *)transverseContactsAutorisationPopupTexte2 transverseContacterAgence:(NSString *)transverseContacterAgence transverseSuivant:(NSString *)transverseSuivant transverseAppUpdateLater:(NSString *)transverseAppUpdateLater transverseBoutonValider:(NSString *)transverseBoutonValider transverseBoutonContinuer:(NSString *)transverseBoutonContinuer transverseBoutonFermer:(NSString *)transverseBoutonFermer transverseBoutonAnnuler:(NSString *)transverseBoutonAnnuler weroP2pContactsTitre:(NSString *)weroP2pContactsTitre weroP2pContactsAccesBouton:(NSString *)weroP2pContactsAccesBouton weroP2pContactsSaisirNumero:(NSString *)weroP2pContactsSaisirNumero weroP2pContactsSaisirEmail:(NSString *)weroP2pContactsSaisirEmail weroP2pContactsBarre:(NSString *)weroP2pContactsBarre weroP2pContactsListe:(NSString *)weroP2pContactsListe weroP2pContactsListeVide:(NSString *)weroP2pContactsListeVide weroP2pContactsPlusieursCoordonneesLibelle:(NSString *)weroP2pContactsPlusieursCoordonneesLibelle weroP2pContactsPlusieursCoordonneesTitre:(NSString *)weroP2pContactsPlusieursCoordonneesTitre weroP2pMontantTitre:(NSString *)weroP2pMontantTitre weroP2pContactProxyEligibleOkTitre:(NSString *)weroP2pContactProxyEligibleOkTitre weroP2pContactProxyEligibleOkMessage:(NSString *)weroP2pContactProxyEligibleOkMessage weroP2pMontantPlafondWeroKo:(NSString *)weroP2pMontantPlafondWeroKo weroP2pMontantPlafondBamKo:(NSString *)weroP2pMontantPlafondBamKo weroP2pMontantPlafondBamKoZero:(NSString *)weroP2pMontantPlafondBamKoZero weroP2pContactsSaisirNumeroTitre:(NSString *)weroP2pContactsSaisirNumeroTitre weroP2pContactsSaisirNumeroInformation:(NSString *)weroP2pContactsSaisirNumeroInformation weroP2pContactsSaisirNumeroNomChamp:(NSString *)weroP2pContactsSaisirNumeroNomChamp weroP2pContactsSaisirNumeroListePaysTitre:(NSString *)weroP2pContactsSaisirNumeroListePaysTitre weroP2pEnrolementEligibiliteTitre:(NSString *)weroP2pEnrolementEligibiliteTitre weroP2pEnrolementEligibiliteMessage1:(NSString *)weroP2pEnrolementEligibiliteMessage1 weroP2pEnrolementEligibiliteCondition1:(NSString *)weroP2pEnrolementEligibiliteCondition1 weroP2pEnrolementEligibiliteCondition2:(NSString *)weroP2pEnrolementEligibiliteCondition2 weroP2pEnrolementEligibiliteCondition3:(NSString *)weroP2pEnrolementEligibiliteCondition3 weroP2pEnrolementEligibiliteCondition4:(NSString *)weroP2pEnrolementEligibiliteCondition4 weroP2pEnrolementEligibiliteMessage2:(NSString *)weroP2pEnrolementEligibiliteMessage2 weroP2pEnrolementTutoEcran1Titre:(NSString *)weroP2pEnrolementTutoEcran1Titre weroP2pEnrolementTutoEcran1Texte:(NSString *)weroP2pEnrolementTutoEcran1Texte weroP2pEnrolementTutoEcran2Titre:(NSString *)weroP2pEnrolementTutoEcran2Titre weroP2pEnrolementTutoEcran2Texte1:(NSString *)weroP2pEnrolementTutoEcran2Texte1 weroP2pEnrolementTutoEcran2Texte2:(NSString *)weroP2pEnrolementTutoEcran2Texte2 weroP2pEnrolementTutoEcran3Titre:(NSString *)weroP2pEnrolementTutoEcran3Titre weroP2pEnrolementTutoEcran3Texte1:(NSString *)weroP2pEnrolementTutoEcran3Texte1 weroP2pEnrolementTutoEcran3Texte2:(NSString *)weroP2pEnrolementTutoEcran3Texte2 weroP2pEnrolementTutoBoutonActiver:(NSString *)weroP2pEnrolementTutoBoutonActiver __attribute__((swift_name("init(transverseAutorisationBoutonReglages:transverseContactsAutorisationIos:transverseContactsAutorisationPopupTitre:transverseContactsAutorisationPopupTexteIos:transverseContactsAutorisationPopupTexte:transverseContactsAutorisationPopupTexte2:transverseContacterAgence:transverseSuivant:transverseAppUpdateLater:transverseBoutonValider:transverseBoutonContinuer:transverseBoutonFermer:transverseBoutonAnnuler:weroP2pContactsTitre:weroP2pContactsAccesBouton:weroP2pContactsSaisirNumero:weroP2pContactsSaisirEmail:weroP2pContactsBarre:weroP2pContactsListe:weroP2pContactsListeVide:weroP2pContactsPlusieursCoordonneesLibelle:weroP2pContactsPlusieursCoordonneesTitre:weroP2pMontantTitre:weroP2pContactProxyEligibleOkTitre:weroP2pContactProxyEligibleOkMessage:weroP2pMontantPlafondWeroKo:weroP2pMontantPlafondBamKo:weroP2pMontantPlafondBamKoZero:weroP2pContactsSaisirNumeroTitre:weroP2pContactsSaisirNumeroInformation:weroP2pContactsSaisirNumeroNomChamp:weroP2pContactsSaisirNumeroListePaysTitre:weroP2pEnrolementEligibiliteTitre:weroP2pEnrolementEligibiliteMessage1:weroP2pEnrolementEligibiliteCondition1:weroP2pEnrolementEligibiliteCondition2:weroP2pEnrolementEligibiliteCondition3:weroP2pEnrolementEligibiliteCondition4:weroP2pEnrolementEligibiliteMessage2:weroP2pEnrolementTutoEcran1Titre:weroP2pEnrolementTutoEcran1Texte:weroP2pEnrolementTutoEcran2Titre:weroP2pEnrolementTutoEcran2Texte1:weroP2pEnrolementTutoEcran2Texte2:weroP2pEnrolementTutoEcran3Titre:weroP2pEnrolementTutoEcran3Texte1:weroP2pEnrolementTutoEcran3Texte2:weroP2pEnrolementTutoBoutonActiver:)"))) __attribute__((objc_designated_initializer));
- (WVMStringResources *)doCopyTransverseAutorisationBoutonReglages:(NSString *)transverseAutorisationBoutonReglages transverseContactsAutorisationIos:(NSString *)transverseContactsAutorisationIos transverseContactsAutorisationPopupTitre:(NSString *)transverseContactsAutorisationPopupTitre transverseContactsAutorisationPopupTexteIos:(NSString *)transverseContactsAutorisationPopupTexteIos transverseContactsAutorisationPopupTexte:(NSString *)transverseContactsAutorisationPopupTexte transverseContactsAutorisationPopupTexte2:(NSString *)transverseContactsAutorisationPopupTexte2 transverseContacterAgence:(NSString *)transverseContacterAgence transverseSuivant:(NSString *)transverseSuivant transverseAppUpdateLater:(NSString *)transverseAppUpdateLater transverseBoutonValider:(NSString *)transverseBoutonValider transverseBoutonContinuer:(NSString *)transverseBoutonContinuer transverseBoutonFermer:(NSString *)transverseBoutonFermer transverseBoutonAnnuler:(NSString *)transverseBoutonAnnuler weroP2pContactsTitre:(NSString *)weroP2pContactsTitre weroP2pContactsAccesBouton:(NSString *)weroP2pContactsAccesBouton weroP2pContactsSaisirNumero:(NSString *)weroP2pContactsSaisirNumero weroP2pContactsSaisirEmail:(NSString *)weroP2pContactsSaisirEmail weroP2pContactsBarre:(NSString *)weroP2pContactsBarre weroP2pContactsListe:(NSString *)weroP2pContactsListe weroP2pContactsListeVide:(NSString *)weroP2pContactsListeVide weroP2pContactsPlusieursCoordonneesLibelle:(NSString *)weroP2pContactsPlusieursCoordonneesLibelle weroP2pContactsPlusieursCoordonneesTitre:(NSString *)weroP2pContactsPlusieursCoordonneesTitre weroP2pMontantTitre:(NSString *)weroP2pMontantTitre weroP2pContactProxyEligibleOkTitre:(NSString *)weroP2pContactProxyEligibleOkTitre weroP2pContactProxyEligibleOkMessage:(NSString *)weroP2pContactProxyEligibleOkMessage weroP2pMontantPlafondWeroKo:(NSString *)weroP2pMontantPlafondWeroKo weroP2pMontantPlafondBamKo:(NSString *)weroP2pMontantPlafondBamKo weroP2pMontantPlafondBamKoZero:(NSString *)weroP2pMontantPlafondBamKoZero weroP2pContactsSaisirNumeroTitre:(NSString *)weroP2pContactsSaisirNumeroTitre weroP2pContactsSaisirNumeroInformation:(NSString *)weroP2pContactsSaisirNumeroInformation weroP2pContactsSaisirNumeroNomChamp:(NSString *)weroP2pContactsSaisirNumeroNomChamp weroP2pContactsSaisirNumeroListePaysTitre:(NSString *)weroP2pContactsSaisirNumeroListePaysTitre weroP2pEnrolementEligibiliteTitre:(NSString *)weroP2pEnrolementEligibiliteTitre weroP2pEnrolementEligibiliteMessage1:(NSString *)weroP2pEnrolementEligibiliteMessage1 weroP2pEnrolementEligibiliteCondition1:(NSString *)weroP2pEnrolementEligibiliteCondition1 weroP2pEnrolementEligibiliteCondition2:(NSString *)weroP2pEnrolementEligibiliteCondition2 weroP2pEnrolementEligibiliteCondition3:(NSString *)weroP2pEnrolementEligibiliteCondition3 weroP2pEnrolementEligibiliteCondition4:(NSString *)weroP2pEnrolementEligibiliteCondition4 weroP2pEnrolementEligibiliteMessage2:(NSString *)weroP2pEnrolementEligibiliteMessage2 weroP2pEnrolementTutoEcran1Titre:(NSString *)weroP2pEnrolementTutoEcran1Titre weroP2pEnrolementTutoEcran1Texte:(NSString *)weroP2pEnrolementTutoEcran1Texte weroP2pEnrolementTutoEcran2Titre:(NSString *)weroP2pEnrolementTutoEcran2Titre weroP2pEnrolementTutoEcran2Texte1:(NSString *)weroP2pEnrolementTutoEcran2Texte1 weroP2pEnrolementTutoEcran2Texte2:(NSString *)weroP2pEnrolementTutoEcran2Texte2 weroP2pEnrolementTutoEcran3Titre:(NSString *)weroP2pEnrolementTutoEcran3Titre weroP2pEnrolementTutoEcran3Texte1:(NSString *)weroP2pEnrolementTutoEcran3Texte1 weroP2pEnrolementTutoEcran3Texte2:(NSString *)weroP2pEnrolementTutoEcran3Texte2 weroP2pEnrolementTutoBoutonActiver:(NSString *)weroP2pEnrolementTutoBoutonActiver __attribute__((swift_name("doCopy(transverseAutorisationBoutonReglages:transverseContactsAutorisationIos:transverseContactsAutorisationPopupTitre:transverseContactsAutorisationPopupTexteIos:transverseContactsAutorisationPopupTexte:transverseContactsAutorisationPopupTexte2:transverseContacterAgence:transverseSuivant:transverseAppUpdateLater:transverseBoutonValider:transverseBoutonContinuer:transverseBoutonFermer:transverseBoutonAnnuler:weroP2pContactsTitre:weroP2pContactsAccesBouton:weroP2pContactsSaisirNumero:weroP2pContactsSaisirEmail:weroP2pContactsBarre:weroP2pContactsListe:weroP2pContactsListeVide:weroP2pContactsPlusieursCoordonneesLibelle:weroP2pContactsPlusieursCoordonneesTitre:weroP2pMontantTitre:weroP2pContactProxyEligibleOkTitre:weroP2pContactProxyEligibleOkMessage:weroP2pMontantPlafondWeroKo:weroP2pMontantPlafondBamKo:weroP2pMontantPlafondBamKoZero:weroP2pContactsSaisirNumeroTitre:weroP2pContactsSaisirNumeroInformation:weroP2pContactsSaisirNumeroNomChamp:weroP2pContactsSaisirNumeroListePaysTitre:weroP2pEnrolementEligibiliteTitre:weroP2pEnrolementEligibiliteMessage1:weroP2pEnrolementEligibiliteCondition1:weroP2pEnrolementEligibiliteCondition2:weroP2pEnrolementEligibiliteCondition3:weroP2pEnrolementEligibiliteCondition4:weroP2pEnrolementEligibiliteMessage2:weroP2pEnrolementTutoEcran1Titre:weroP2pEnrolementTutoEcran1Texte:weroP2pEnrolementTutoEcran2Titre:weroP2pEnrolementTutoEcran2Texte1:weroP2pEnrolementTutoEcran2Texte2:weroP2pEnrolementTutoEcran3Titre:weroP2pEnrolementTutoEcran3Texte1:weroP2pEnrolementTutoEcran3Texte2:weroP2pEnrolementTutoBoutonActiver:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *transverseAppUpdateLater __attribute__((swift_name("transverseAppUpdateLater")));
@property (readonly) NSString *transverseAutorisationBoutonReglages __attribute__((swift_name("transverseAutorisationBoutonReglages")));
@property (readonly) NSString *transverseBoutonAnnuler __attribute__((swift_name("transverseBoutonAnnuler")));
@property (readonly) NSString *transverseBoutonContinuer __attribute__((swift_name("transverseBoutonContinuer")));
@property (readonly) NSString *transverseBoutonFermer __attribute__((swift_name("transverseBoutonFermer")));
@property (readonly) NSString *transverseBoutonValider __attribute__((swift_name("transverseBoutonValider")));
@property (readonly) NSString *transverseContacterAgence __attribute__((swift_name("transverseContacterAgence")));
@property (readonly) NSString *transverseContactsAutorisationIos __attribute__((swift_name("transverseContactsAutorisationIos")));
@property (readonly) NSString *transverseContactsAutorisationPopupTexte __attribute__((swift_name("transverseContactsAutorisationPopupTexte")));
@property (readonly) NSString *transverseContactsAutorisationPopupTexte2 __attribute__((swift_name("transverseContactsAutorisationPopupTexte2")));
@property (readonly) NSString *transverseContactsAutorisationPopupTexteIos __attribute__((swift_name("transverseContactsAutorisationPopupTexteIos")));
@property (readonly) NSString *transverseContactsAutorisationPopupTitre __attribute__((swift_name("transverseContactsAutorisationPopupTitre")));
@property (readonly) NSString *transverseSuivant __attribute__((swift_name("transverseSuivant")));
@property (readonly) NSString *weroP2pContactProxyEligibleOkMessage __attribute__((swift_name("weroP2pContactProxyEligibleOkMessage")));
@property (readonly) NSString *weroP2pContactProxyEligibleOkTitre __attribute__((swift_name("weroP2pContactProxyEligibleOkTitre")));
@property (readonly) NSString *weroP2pContactsAccesBouton __attribute__((swift_name("weroP2pContactsAccesBouton")));
@property (readonly) NSString *weroP2pContactsBarre __attribute__((swift_name("weroP2pContactsBarre")));
@property (readonly) NSString *weroP2pContactsListe __attribute__((swift_name("weroP2pContactsListe")));
@property (readonly) NSString *weroP2pContactsListeVide __attribute__((swift_name("weroP2pContactsListeVide")));
@property (readonly) NSString *weroP2pContactsPlusieursCoordonneesLibelle __attribute__((swift_name("weroP2pContactsPlusieursCoordonneesLibelle")));
@property (readonly) NSString *weroP2pContactsPlusieursCoordonneesTitre __attribute__((swift_name("weroP2pContactsPlusieursCoordonneesTitre")));
@property (readonly) NSString *weroP2pContactsSaisirEmail __attribute__((swift_name("weroP2pContactsSaisirEmail")));
@property (readonly) NSString *weroP2pContactsSaisirNumero __attribute__((swift_name("weroP2pContactsSaisirNumero")));
@property (readonly) NSString *weroP2pContactsSaisirNumeroInformation __attribute__((swift_name("weroP2pContactsSaisirNumeroInformation")));
@property (readonly) NSString *weroP2pContactsSaisirNumeroListePaysTitre __attribute__((swift_name("weroP2pContactsSaisirNumeroListePaysTitre")));
@property (readonly) NSString *weroP2pContactsSaisirNumeroNomChamp __attribute__((swift_name("weroP2pContactsSaisirNumeroNomChamp")));
@property (readonly) NSString *weroP2pContactsSaisirNumeroTitre __attribute__((swift_name("weroP2pContactsSaisirNumeroTitre")));
@property (readonly) NSString *weroP2pContactsTitre __attribute__((swift_name("weroP2pContactsTitre")));
@property (readonly) NSString *weroP2pEnrolementEligibiliteCondition1 __attribute__((swift_name("weroP2pEnrolementEligibiliteCondition1")));
@property (readonly) NSString *weroP2pEnrolementEligibiliteCondition2 __attribute__((swift_name("weroP2pEnrolementEligibiliteCondition2")));
@property (readonly) NSString *weroP2pEnrolementEligibiliteCondition3 __attribute__((swift_name("weroP2pEnrolementEligibiliteCondition3")));
@property (readonly) NSString *weroP2pEnrolementEligibiliteCondition4 __attribute__((swift_name("weroP2pEnrolementEligibiliteCondition4")));
@property (readonly) NSString *weroP2pEnrolementEligibiliteMessage1 __attribute__((swift_name("weroP2pEnrolementEligibiliteMessage1")));
@property (readonly) NSString *weroP2pEnrolementEligibiliteMessage2 __attribute__((swift_name("weroP2pEnrolementEligibiliteMessage2")));
@property (readonly) NSString *weroP2pEnrolementEligibiliteTitre __attribute__((swift_name("weroP2pEnrolementEligibiliteTitre")));
@property (readonly) NSString *weroP2pEnrolementTutoBoutonActiver __attribute__((swift_name("weroP2pEnrolementTutoBoutonActiver")));
@property (readonly) NSString *weroP2pEnrolementTutoEcran1Texte __attribute__((swift_name("weroP2pEnrolementTutoEcran1Texte")));
@property (readonly) NSString *weroP2pEnrolementTutoEcran1Titre __attribute__((swift_name("weroP2pEnrolementTutoEcran1Titre")));
@property (readonly) NSString *weroP2pEnrolementTutoEcran2Texte1 __attribute__((swift_name("weroP2pEnrolementTutoEcran2Texte1")));
@property (readonly) NSString *weroP2pEnrolementTutoEcran2Texte2 __attribute__((swift_name("weroP2pEnrolementTutoEcran2Texte2")));
@property (readonly) NSString *weroP2pEnrolementTutoEcran2Titre __attribute__((swift_name("weroP2pEnrolementTutoEcran2Titre")));
@property (readonly) NSString *weroP2pEnrolementTutoEcran3Texte1 __attribute__((swift_name("weroP2pEnrolementTutoEcran3Texte1")));
@property (readonly) NSString *weroP2pEnrolementTutoEcran3Texte2 __attribute__((swift_name("weroP2pEnrolementTutoEcran3Texte2")));
@property (readonly) NSString *weroP2pEnrolementTutoEcran3Titre __attribute__((swift_name("weroP2pEnrolementTutoEcran3Titre")));
@property (readonly) NSString *weroP2pMontantPlafondBamKo __attribute__((swift_name("weroP2pMontantPlafondBamKo")));
@property (readonly) NSString *weroP2pMontantPlafondBamKoZero __attribute__((swift_name("weroP2pMontantPlafondBamKoZero")));
@property (readonly) NSString *weroP2pMontantPlafondWeroKo __attribute__((swift_name("weroP2pMontantPlafondWeroKo")));
@property (readonly) NSString *weroP2pMontantTitre __attribute__((swift_name("weroP2pMontantTitre")));
@end

__attribute__((swift_name("MainUiState")))
@interface WVMMainUiState : WVMBase
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MainUiState.Loading")))
@interface WVMMainUiStateLoading : WVMMainUiState
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)loading __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMMainUiStateLoading *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MainUiState.Success")))
@interface WVMMainUiStateSuccess : WVMMainUiState
- (instancetype)initWithWelcomeTitle:(WVMResourcesStringDesc *)welcomeTitle buttonText:(WVMResourcesStringDesc *)buttonText __attribute__((swift_name("init(welcomeTitle:buttonText:)"))) __attribute__((objc_designated_initializer));
- (WVMMainUiStateSuccess *)doCopyWelcomeTitle:(WVMResourcesStringDesc *)welcomeTitle buttonText:(WVMResourcesStringDesc *)buttonText __attribute__((swift_name("doCopy(welcomeTitle:buttonText:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) WVMResourcesStringDesc *buttonText __attribute__((swift_name("buttonText")));
@property (readonly) WVMResourcesStringDesc *welcomeTitle __attribute__((swift_name("welcomeTitle")));
@end

__attribute__((swift_name("ViewmodelViewModel")))
@interface WVMViewmodelViewModel : WVMBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithCloseables:(WVMKotlinArray<id<WVMKotlinAutoCloseable>> *)closeables __attribute__((swift_name("init(closeables:)"))) __attribute__((objc_designated_initializer));
- (void)close __attribute__((swift_name("close()")));
@property (readonly) id<WVMKotlinx_coroutines_coreCoroutineScope> viewModelScope __attribute__((swift_name("viewModelScope")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FirstViewModelDelegate")))
@interface WVMFirstViewModelDelegate : WVMViewmodelViewModel
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithCloseables:(WVMKotlinArray<id<WVMKotlinAutoCloseable>> *)closeables __attribute__((swift_name("init(closeables:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (id<WVMKotlinx_coroutines_coreJob>)refresh __attribute__((swift_name("refresh()")));
@property (readonly) WVMFlowCoreStateFlow<WVMMainUiState *> *viewState __attribute__((swift_name("viewState")));
@end

__attribute__((swift_name("FactStateUiModel")))
@interface WVMFactStateUiModel : WVMBase
@property (readonly) WVMResourcesStringDesc *buttonRefresh __attribute__((swift_name("buttonRefresh")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FactStateUiModel.Error")))
@interface WVMFactStateUiModelError : WVMFactStateUiModel
- (instancetype)initWithError:(NSString *)error __attribute__((swift_name("init(error:)"))) __attribute__((objc_designated_initializer));
- (WVMFactStateUiModelError *)doCopyError:(NSString *)error __attribute__((swift_name("doCopy(error:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *error __attribute__((swift_name("error")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FactStateUiModel.Loading")))
@interface WVMFactStateUiModelLoading : WVMFactStateUiModel
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)loading __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMFactStateUiModelLoading *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FactStateUiModel.Success")))
@interface WVMFactStateUiModelSuccess : WVMFactStateUiModel
- (instancetype)initWithFact:(NSString *)fact __attribute__((swift_name("init(fact:)"))) __attribute__((objc_designated_initializer));
- (WVMFactStateUiModelSuccess *)doCopyFact:(NSString *)fact __attribute__((swift_name("doCopy(fact:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *fact __attribute__((swift_name("fact")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SecondViewModelDelegate")))
@interface WVMSecondViewModelDelegate : WVMViewmodelViewModel
- (instancetype)initWithNetworkViewModelMapper:(WVMNetworkViewModelMapper *)networkViewModelMapper getFactUseCase:(WVMDomain_factGetFactUseCase *)getFactUseCase __attribute__((swift_name("init(networkViewModelMapper:getFactUseCase:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithCloseables:(WVMKotlinArray<id<WVMKotlinAutoCloseable>> *)closeables __attribute__((swift_name("init(closeables:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (id<WVMKotlinx_coroutines_coreJob>)refreshForceToRefresh:(BOOL)forceToRefresh __attribute__((swift_name("refresh(forceToRefresh:)")));
@property (readonly) WVMFlowCoreStateFlow<WVMFactStateUiModel *> *viewState __attribute__((swift_name("viewState")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NetworkViewModelMapper")))
@interface WVMNetworkViewModelMapper : WVMBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (WVMFactStateUiModel *)mapResult:(id<WVMDomain_factGetFactUseCaseStateModel>)result __attribute__((swift_name("map(result:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("InternalWeroModuleKt")))
@interface WVMInternalWeroModuleKt : WVMBase
+ (WVMKoin_coreModule *)internalWeroModulesHttpClient:(WVMKtor_client_coreHttpClient *)httpClient __attribute__((swift_name("internalWeroModules(httpClient:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StringsResourcesKt")))
@interface WVMStringsResourcesKt : WVMBase
+ (WVMStringResources *)stringResourcesEn __attribute__((swift_name("stringResourcesEn()")));
+ (WVMStringResources *)stringResourcesFr __attribute__((swift_name("stringResourcesFr()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ViewModelsModuleKt")))
@interface WVMViewModelsModuleKt : WVMBase
@property (class, readonly) WVMKoin_coreModule *viewModelsModule __attribute__((swift_name("viewModelsModule")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineScope")))
@protocol WVMKotlinx_coroutines_coreCoroutineScope
@required
@property (readonly) id<WVMKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end

__attribute__((swift_name("Ktor_ioCloseable")))
@protocol WVMKtor_ioCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClient")))
@interface WVMKtor_client_coreHttpClient : WVMBase <WVMKotlinx_coroutines_coreCoroutineScope, WVMKtor_ioCloseable>
- (instancetype)initWithEngine:(id<WVMKtor_client_coreHttpClientEngine>)engine userConfig:(WVMKtor_client_coreHttpClientConfig<WVMKtor_client_coreHttpClientEngineConfig *> *)userConfig __attribute__((swift_name("init(engine:userConfig:)"))) __attribute__((objc_designated_initializer));
- (void)close __attribute__((swift_name("close()")));
- (WVMKtor_client_coreHttpClient *)configBlock:(void (^)(WVMKtor_client_coreHttpClientConfig<id> *))block __attribute__((swift_name("config(block:)")));
- (BOOL)isSupportedCapability:(id<WVMKtor_client_coreHttpClientEngineCapability>)capability __attribute__((swift_name("isSupported(capability:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<WVMKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) id<WVMKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<WVMKtor_client_coreHttpClientEngine> engine __attribute__((swift_name("engine")));
@property (readonly) WVMKtor_client_coreHttpClientEngineConfig *engineConfig __attribute__((swift_name("engineConfig")));
@property (readonly) WVMKtor_eventsEvents *monitor __attribute__((swift_name("monitor")));
@property (readonly) WVMKtor_client_coreHttpReceivePipeline *receivePipeline __attribute__((swift_name("receivePipeline")));
@property (readonly) WVMKtor_client_coreHttpRequestPipeline *requestPipeline __attribute__((swift_name("requestPipeline")));
@property (readonly) WVMKtor_client_coreHttpResponsePipeline *responsePipeline __attribute__((swift_name("responsePipeline")));
@property (readonly) WVMKtor_client_coreHttpSendPipeline *sendPipeline __attribute__((swift_name("sendPipeline")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface WVMKotlinEnumCompanion : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface WVMKotlinArray<T> : WVMBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(WVMInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<WVMKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_loggingLogLevel")))
@interface WVMKtor_client_loggingLogLevel : WVMKotlinEnum<WVMKtor_client_loggingLogLevel *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) WVMKtor_client_loggingLogLevel *all __attribute__((swift_name("all")));
@property (class, readonly) WVMKtor_client_loggingLogLevel *headers __attribute__((swift_name("headers")));
@property (class, readonly) WVMKtor_client_loggingLogLevel *body __attribute__((swift_name("body")));
@property (class, readonly) WVMKtor_client_loggingLogLevel *info __attribute__((swift_name("info")));
@property (class, readonly) WVMKtor_client_loggingLogLevel *none __attribute__((swift_name("none")));
+ (WVMKotlinArray<WVMKtor_client_loggingLogLevel *> *)values __attribute__((swift_name("values()")));
@property (readonly) BOOL body __attribute__((swift_name("body")));
@property (readonly) BOOL headers __attribute__((swift_name("headers")));
@property (readonly) BOOL info __attribute__((swift_name("info")));
@end

__attribute__((swift_name("Ktor_client_coreHttpClientPlugin")))
@protocol WVMKtor_client_coreHttpClientPlugin
@required
- (void)installPlugin:(id)plugin scope:(WVMKtor_client_coreHttpClient *)scope __attribute__((swift_name("install(plugin:scope:)")));
- (id)prepareBlock:(void (^)(id))block __attribute__((swift_name("prepare(block:)")));
@property (readonly) WVMKtor_utilsAttributeKey<id> *key __attribute__((swift_name("key")));
@end

__attribute__((swift_name("Ktor_client_coreClientPlugin")))
@protocol WVMKtor_client_coreClientPlugin <WVMKtor_client_coreHttpClientPlugin>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ResourcesStringDesc")))
@interface WVMResourcesStringDesc : WVMBase
- (instancetype)initWithTranslations:(NSDictionary<NSString *, NSString *> *)translations defaultLanguage:(NSString *)defaultLanguage __attribute__((swift_name("init(translations:defaultLanguage:)"))) __attribute__((objc_designated_initializer));
- (NSString *)localized __attribute__((swift_name("localized()")));
- (NSString *)localizedArgs:(WVMKotlinArray<NSString *> *)args __attribute__((swift_name("localized(args:)")));
@property (readonly) NSString *defaultLanguage __attribute__((swift_name("defaultLanguage")));
@property (readonly) NSDictionary<NSString *, NSString *> *translations __attribute__((swift_name("translations")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.8")
 *   kotlin.ExperimentalStdlibApi
*/
__attribute__((swift_name("KotlinAutoCloseable")))
@protocol WVMKotlinAutoCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinCoroutineContext")))
@protocol WVMKotlinCoroutineContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, id<WVMKotlinCoroutineContextElement>))operation __attribute__((swift_name("fold(initial:operation:)")));
- (id<WVMKotlinCoroutineContextElement> _Nullable)getKey:(id<WVMKotlinCoroutineContextKey>)key __attribute__((swift_name("get(key:)")));
- (id<WVMKotlinCoroutineContext>)minusKeyKey:(id<WVMKotlinCoroutineContextKey>)key __attribute__((swift_name("minusKey(key:)")));
- (id<WVMKotlinCoroutineContext>)plusContext:(id<WVMKotlinCoroutineContext>)context __attribute__((swift_name("plus(context:)")));
@end

__attribute__((swift_name("KotlinCoroutineContextElement")))
@protocol WVMKotlinCoroutineContextElement <WVMKotlinCoroutineContext>
@required
@property (readonly) id<WVMKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreJob")))
@protocol WVMKotlinx_coroutines_coreJob <WVMKotlinCoroutineContextElement>
@required
- (id<WVMKotlinx_coroutines_coreChildHandle>)attachChildChild:(id<WVMKotlinx_coroutines_coreChildJob>)child __attribute__((swift_name("attachChild(child:)")));
- (void)cancelCause:(WVMKotlinCancellationException * _Nullable)cause __attribute__((swift_name("cancel(cause:)")));
- (WVMKotlinCancellationException *)getCancellationException __attribute__((swift_name("getCancellationException()")));
- (id<WVMKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionHandler:(void (^)(WVMKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(handler:)")));
- (id<WVMKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionOnCancelling:(BOOL)onCancelling invokeImmediately:(BOOL)invokeImmediately handler:(void (^)(WVMKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(onCancelling:invokeImmediately:handler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)joinWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("join(completionHandler:)")));
- (id<WVMKotlinx_coroutines_coreJob>)plusOther:(id<WVMKotlinx_coroutines_coreJob>)other __attribute__((swift_name("plus(other:)"))) __attribute__((unavailable("Operator '+' on two Job objects is meaningless. Job is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The job to the right of `+` just replaces the job the left of `+`.")));
- (BOOL)start __attribute__((swift_name("start()")));
@property (readonly) id<WVMKotlinSequence> children __attribute__((swift_name("children")));
@property (readonly) BOOL isActive __attribute__((swift_name("isActive")));
@property (readonly) BOOL isCancelled __attribute__((swift_name("isCancelled")));
@property (readonly) BOOL isCompleted __attribute__((swift_name("isCompleted")));
@property (readonly) id<WVMKotlinx_coroutines_coreSelectClause0> onJoin __attribute__((swift_name("onJoin")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
@property (readonly) id<WVMKotlinx_coroutines_coreJob> _Nullable parent __attribute__((swift_name("parent")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlow")))
@protocol WVMKotlinx_coroutines_coreFlow
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<WVMKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSharedFlow")))
@protocol WVMKotlinx_coroutines_coreSharedFlow <WVMKotlinx_coroutines_coreFlow>
@required
@property (readonly) NSArray<id> *replayCache __attribute__((swift_name("replayCache")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreStateFlow")))
@protocol WVMKotlinx_coroutines_coreStateFlow <WVMKotlinx_coroutines_coreSharedFlow>
@required
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FlowCoreStateFlow")))
@interface WVMFlowCoreStateFlow<T> : WVMBase <WVMKotlinx_coroutines_coreStateFlow>
- (instancetype)initWithSource:(id<WVMKotlinx_coroutines_coreStateFlow>)source __attribute__((swift_name("init(source:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<WVMKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
- (id<WVMKotlinx_coroutines_coreDisposableHandle>)subscribeOnEach:(void (^)(T _Nullable))onEach onCompletion:(void (^ _Nullable)(WVMKotlinThrowable * _Nullable))onCompletion __attribute__((swift_name("subscribe(onEach:onCompletion:)")));
- (id<WVMKotlinx_coroutines_coreDisposableHandle>)subscribeCoroutineScope:(id<WVMKotlinx_coroutines_coreCoroutineScope>)coroutineScope dispatcher:(WVMKotlinx_coroutines_coreCoroutineDispatcher *)dispatcher onEach:(void (^)(T _Nullable))onEach onCompletion:(void (^ _Nullable)(WVMKotlinThrowable * _Nullable))onCompletion __attribute__((swift_name("subscribe(coroutineScope:dispatcher:onEach:onCompletion:)")));
@property (readonly) NSArray<id> *replayCache __attribute__((swift_name("replayCache")));
@property (readonly) T _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Domain_factGetFactUseCase")))
@interface WVMDomain_factGetFactUseCase : WVMBase
- (instancetype)initWithFactEntity:(id<WVMEntity_factFactEntity>)factEntity mapper:(WVMDomain_factGetFactUseCaseMappers *)mapper retrieveMapper:(WVMDomain_factRetrieveFactUseCaseMappers *)retrieveMapper factRepository:(id<WVMData_factFactRepository>)factRepository dispatcher:(WVMCore_commonsDispatchers *)dispatcher __attribute__((swift_name("init(factEntity:mapper:retrieveMapper:factRepository:dispatcher:)"))) __attribute__((objc_designated_initializer));
- (id<WVMKotlinx_coroutines_coreFlow>)invokeRefresh:(BOOL)refresh __attribute__((swift_name("invoke(refresh:)")));
@end

__attribute__((swift_name("Domain_factGetFactUseCaseStateModel")))
@protocol WVMDomain_factGetFactUseCaseStateModel
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreModule")))
@interface WVMKoin_coreModule : WVMBase
- (instancetype)initWith_createdAtStart:(BOOL)_createdAtStart __attribute__((swift_name("init(_createdAtStart:)"))) __attribute__((objc_designated_initializer));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (WVMKoin_coreKoinDefinition<id> *)factoryQualifier:(id<WVMKoin_coreQualifier> _Nullable)qualifier definition:(id _Nullable (^)(WVMKoin_coreScope *, WVMKoin_coreParametersHolder *))definition __attribute__((swift_name("factory(qualifier:definition:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (void)includesModule:(WVMKotlinArray<WVMKoin_coreModule *> *)module __attribute__((swift_name("includes(module:)")));
- (void)includesModule_:(id)module __attribute__((swift_name("includes(module_:)")));
- (void)indexPrimaryTypeInstanceFactory:(WVMKoin_coreInstanceFactory<id> *)instanceFactory __attribute__((swift_name("indexPrimaryType(instanceFactory:)")));
- (void)indexSecondaryTypesInstanceFactory:(WVMKoin_coreInstanceFactory<id> *)instanceFactory __attribute__((swift_name("indexSecondaryTypes(instanceFactory:)")));
- (NSArray<WVMKoin_coreModule *> *)plusModules:(NSArray<WVMKoin_coreModule *> *)modules __attribute__((swift_name("plus(modules:)")));
- (NSArray<WVMKoin_coreModule *> *)plusModule:(WVMKoin_coreModule *)module __attribute__((swift_name("plus(module:)")));
- (void)prepareForCreationAtStartInstanceFactory:(WVMKoin_coreSingleInstanceFactory<id> *)instanceFactory __attribute__((swift_name("prepareForCreationAtStart(instanceFactory:)")));
- (void)scopeScopeSet:(void (^)(WVMKoin_coreScopeDSL *))scopeSet __attribute__((swift_name("scope(scopeSet:)")));
- (void)scopeQualifier:(id<WVMKoin_coreQualifier>)qualifier scopeSet:(void (^)(WVMKoin_coreScopeDSL *))scopeSet __attribute__((swift_name("scope(qualifier:scopeSet:)")));
- (WVMKoin_coreKoinDefinition<id> *)singleQualifier:(id<WVMKoin_coreQualifier> _Nullable)qualifier createdAtStart:(BOOL)createdAtStart definition:(id _Nullable (^)(WVMKoin_coreScope *, WVMKoin_coreParametersHolder *))definition __attribute__((swift_name("single(qualifier:createdAtStart:definition:)")));
@property (readonly) WVMMutableSet<WVMKoin_coreSingleInstanceFactory<id> *> *eagerInstances __attribute__((swift_name("eagerInstances")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSMutableArray<WVMKoin_coreModule *> *includedModules __attribute__((swift_name("includedModules")));
@property (readonly) BOOL isLoaded __attribute__((swift_name("isLoaded")));
@property (readonly) WVMMutableDictionary<NSString *, WVMKoin_coreInstanceFactory<id> *> *mappings __attribute__((swift_name("mappings")));
@end

__attribute__((swift_name("Ktor_client_coreHttpClientEngine")))
@protocol WVMKtor_client_coreHttpClientEngine <WVMKotlinx_coroutines_coreCoroutineScope, WVMKtor_ioCloseable>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeData:(WVMKtor_client_coreHttpRequestData *)data completionHandler:(void (^)(WVMKtor_client_coreHttpResponseData * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(data:completionHandler:)")));
- (void)installClient:(WVMKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
@property (readonly) WVMKtor_client_coreHttpClientEngineConfig *config __attribute__((swift_name("config")));
@property (readonly) WVMKotlinx_coroutines_coreCoroutineDispatcher *dispatcher __attribute__((swift_name("dispatcher")));
@property (readonly) NSSet<id<WVMKtor_client_coreHttpClientEngineCapability>> *supportedCapabilities __attribute__((swift_name("supportedCapabilities")));
@end

__attribute__((swift_name("Ktor_client_coreHttpClientEngineConfig")))
@interface WVMKtor_client_coreHttpClientEngineConfig : WVMBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property BOOL pipelining __attribute__((swift_name("pipelining")));
@property WVMKtor_client_coreProxyConfig * _Nullable proxy __attribute__((swift_name("proxy")));
@property int32_t threadsCount __attribute__((swift_name("threadsCount"))) __attribute__((deprecated("The [threadsCount] property is deprecated. The [Dispatchers.IO] is used by default.")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientConfig")))
@interface WVMKtor_client_coreHttpClientConfig<T> : WVMBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (WVMKtor_client_coreHttpClientConfig<T> *)clone __attribute__((swift_name("clone()")));
- (void)engineBlock:(void (^)(T))block __attribute__((swift_name("engine(block:)")));
- (void)installClient:(WVMKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
- (void)installPlugin:(id<WVMKtor_client_coreHttpClientPlugin>)plugin configure:(void (^)(id))configure __attribute__((swift_name("install(plugin:configure:)")));
- (void)installKey:(NSString *)key block:(void (^)(WVMKtor_client_coreHttpClient *))block __attribute__((swift_name("install(key:block:)")));
- (void)plusAssignOther:(WVMKtor_client_coreHttpClientConfig<T> *)other __attribute__((swift_name("plusAssign(other:)")));
@property BOOL developmentMode __attribute__((swift_name("developmentMode")));
@property BOOL expectSuccess __attribute__((swift_name("expectSuccess")));
@property BOOL followRedirects __attribute__((swift_name("followRedirects")));
@property BOOL useDefaultTransformers __attribute__((swift_name("useDefaultTransformers")));
@end

__attribute__((swift_name("Ktor_client_coreHttpClientEngineCapability")))
@protocol WVMKtor_client_coreHttpClientEngineCapability
@required
@end

__attribute__((swift_name("Ktor_utilsAttributes")))
@protocol WVMKtor_utilsAttributes
@required
- (id)computeIfAbsentKey:(WVMKtor_utilsAttributeKey<id> *)key block:(id (^)(void))block __attribute__((swift_name("computeIfAbsent(key:block:)")));
- (BOOL)containsKey:(WVMKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("contains(key:)")));
- (id)getKey_:(WVMKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("get(key_:)")));
- (id _Nullable)getOrNullKey:(WVMKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getOrNull(key:)")));
- (void)putKey:(WVMKtor_utilsAttributeKey<id> *)key value:(id)value __attribute__((swift_name("put(key:value:)")));
- (void)removeKey:(WVMKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("remove(key:)")));
- (id)takeKey:(WVMKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("take(key:)")));
- (id _Nullable)takeOrNullKey:(WVMKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("takeOrNull(key:)")));
@property (readonly) NSArray<WVMKtor_utilsAttributeKey<id> *> *allKeys __attribute__((swift_name("allKeys")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_eventsEvents")))
@interface WVMKtor_eventsEvents : WVMBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)raiseDefinition:(WVMKtor_eventsEventDefinition<id> *)definition value:(id _Nullable)value __attribute__((swift_name("raise(definition:value:)")));
- (id<WVMKotlinx_coroutines_coreDisposableHandle>)subscribeDefinition:(WVMKtor_eventsEventDefinition<id> *)definition handler:(void (^)(id _Nullable))handler __attribute__((swift_name("subscribe(definition:handler:)")));
- (void)unsubscribeDefinition:(WVMKtor_eventsEventDefinition<id> *)definition handler:(void (^)(id _Nullable))handler __attribute__((swift_name("unsubscribe(definition:handler:)")));
@end

__attribute__((swift_name("Ktor_utilsPipeline")))
@interface WVMKtor_utilsPipeline<TSubject, TContext> : WVMBase
- (instancetype)initWithPhases:(WVMKotlinArray<WVMKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhase:(WVMKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<WVMKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer));
- (void)addPhasePhase:(WVMKtor_utilsPipelinePhase *)phase __attribute__((swift_name("addPhase(phase:)")));
- (void)afterIntercepted __attribute__((swift_name("afterIntercepted()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeContext:(TContext)context subject:(TSubject)subject completionHandler:(void (^)(TSubject _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(context:subject:completionHandler:)")));
- (void)insertPhaseAfterReference:(WVMKtor_utilsPipelinePhase *)reference phase:(WVMKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseAfter(reference:phase:)")));
- (void)insertPhaseBeforeReference:(WVMKtor_utilsPipelinePhase *)reference phase:(WVMKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseBefore(reference:phase:)")));
- (void)interceptPhase:(WVMKtor_utilsPipelinePhase *)phase block:(id<WVMKotlinSuspendFunction2>)block __attribute__((swift_name("intercept(phase:block:)")));
- (NSArray<id<WVMKotlinSuspendFunction2>> *)interceptorsForPhasePhase:(WVMKtor_utilsPipelinePhase *)phase __attribute__((swift_name("interceptorsForPhase(phase:)")));
- (void)mergeFrom:(WVMKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("merge(from:)")));
- (void)mergePhasesFrom:(WVMKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("mergePhases(from:)")));
- (void)resetFromFrom:(WVMKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("resetFrom(from:)")));
@property (readonly) id<WVMKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@property (readonly) BOOL isEmpty __attribute__((swift_name("isEmpty")));
@property (readonly) NSArray<WVMKtor_utilsPipelinePhase *> *items __attribute__((swift_name("items")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline")))
@interface WVMKtor_client_coreHttpReceivePipeline : WVMKtor_utilsPipeline<WVMKtor_client_coreHttpResponse *, WVMKotlinUnit *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(WVMKotlinArray<WVMKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(WVMKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<WVMKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) WVMKtor_client_coreHttpReceivePipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline")))
@interface WVMKtor_client_coreHttpRequestPipeline : WVMKtor_utilsPipeline<id, WVMKtor_client_coreHttpRequestBuilder *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(WVMKotlinArray<WVMKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(WVMKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<WVMKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) WVMKtor_client_coreHttpRequestPipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline")))
@interface WVMKtor_client_coreHttpResponsePipeline : WVMKtor_utilsPipeline<WVMKtor_client_coreHttpResponseContainer *, WVMKtor_client_coreHttpClientCall *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(WVMKotlinArray<WVMKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(WVMKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<WVMKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) WVMKtor_client_coreHttpResponsePipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline")))
@interface WVMKtor_client_coreHttpSendPipeline : WVMKtor_utilsPipeline<id, WVMKtor_client_coreHttpRequestBuilder *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(WVMKotlinArray<WVMKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(WVMKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<WVMKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) WVMKtor_client_coreHttpSendPipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol WVMKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsAttributeKey")))
@interface WVMKtor_utilsAttributeKey<T> : WVMBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((swift_name("KotlinThrowable")))
@interface WVMKotlinThrowable : WVMBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(WVMKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(WVMKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
*/
- (WVMKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) WVMKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end

__attribute__((swift_name("KotlinException")))
@interface WVMKotlinException : WVMKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(WVMKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(WVMKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinRuntimeException")))
@interface WVMKotlinRuntimeException : WVMKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(WVMKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(WVMKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinIllegalStateException")))
@interface WVMKotlinIllegalStateException : WVMKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(WVMKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(WVMKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.4")
*/
__attribute__((swift_name("KotlinCancellationException")))
@interface WVMKotlinCancellationException : WVMKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(WVMKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(WVMKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreDisposableHandle")))
@protocol WVMKotlinx_coroutines_coreDisposableHandle
@required
- (void)dispose __attribute__((swift_name("dispose()")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreChildHandle")))
@protocol WVMKotlinx_coroutines_coreChildHandle <WVMKotlinx_coroutines_coreDisposableHandle>
@required
- (BOOL)childCancelledCause:(WVMKotlinThrowable *)cause __attribute__((swift_name("childCancelled(cause:)")));
@property (readonly) id<WVMKotlinx_coroutines_coreJob> _Nullable parent __attribute__((swift_name("parent")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreChildJob")))
@protocol WVMKotlinx_coroutines_coreChildJob <WVMKotlinx_coroutines_coreJob>
@required
- (void)parentCancelledParentJob:(id<WVMKotlinx_coroutines_coreParentJob>)parentJob __attribute__((swift_name("parentCancelled(parentJob:)")));
@end

__attribute__((swift_name("KotlinSequence")))
@protocol WVMKotlinSequence
@required
- (id<WVMKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSelectClause")))
@protocol WVMKotlinx_coroutines_coreSelectClause
@required
@property (readonly) id clauseObject __attribute__((swift_name("clauseObject")));
@property (readonly) WVMKotlinUnit *(^(^ _Nullable onCancellationConstructor)(id<WVMKotlinx_coroutines_coreSelectInstance>, id _Nullable, id _Nullable))(WVMKotlinThrowable *) __attribute__((swift_name("onCancellationConstructor")));
@property (readonly) id _Nullable (^processResFunc)(id, id _Nullable, id _Nullable) __attribute__((swift_name("processResFunc")));
@property (readonly) void (^regFunc)(id, id<WVMKotlinx_coroutines_coreSelectInstance>, id _Nullable) __attribute__((swift_name("regFunc")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSelectClause0")))
@protocol WVMKotlinx_coroutines_coreSelectClause0 <WVMKotlinx_coroutines_coreSelectClause>
@required
@end

__attribute__((swift_name("KotlinCoroutineContextKey")))
@protocol WVMKotlinCoroutineContextKey
@required
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlowCollector")))
@protocol WVMKotlinx_coroutines_coreFlowCollector
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(id _Nullable)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinAbstractCoroutineContextElement")))
@interface WVMKotlinAbstractCoroutineContextElement : WVMBase <WVMKotlinCoroutineContextElement>
- (instancetype)initWithKey:(id<WVMKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<WVMKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinContinuationInterceptor")))
@protocol WVMKotlinContinuationInterceptor <WVMKotlinCoroutineContextElement>
@required
- (id<WVMKotlinContinuation>)interceptContinuationContinuation:(id<WVMKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (void)releaseInterceptedContinuationContinuation:(id<WVMKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher")))
@interface WVMKotlinx_coroutines_coreCoroutineDispatcher : WVMKotlinAbstractCoroutineContextElement <WVMKotlinContinuationInterceptor>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithKey:(id<WVMKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) WVMKotlinx_coroutines_coreCoroutineDispatcherKey *companion __attribute__((swift_name("companion")));
- (void)dispatchContext:(id<WVMKotlinCoroutineContext>)context block:(id<WVMKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatch(context:block:)")));
- (void)dispatchYieldContext:(id<WVMKotlinCoroutineContext>)context block:(id<WVMKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatchYield(context:block:)")));
- (id<WVMKotlinContinuation>)interceptContinuationContinuation:(id<WVMKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (BOOL)isDispatchNeededContext:(id<WVMKotlinCoroutineContext>)context __attribute__((swift_name("isDispatchNeeded(context:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
- (WVMKotlinx_coroutines_coreCoroutineDispatcher *)limitedParallelismParallelism:(int32_t)parallelism __attribute__((swift_name("limitedParallelism(parallelism:)")));
- (WVMKotlinx_coroutines_coreCoroutineDispatcher *)plusOther_:(WVMKotlinx_coroutines_coreCoroutineDispatcher *)other __attribute__((swift_name("plus(other_:)"))) __attribute__((unavailable("Operator '+' on two CoroutineDispatcher objects is meaningless. CoroutineDispatcher is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The dispatcher to the right of `+` just replaces the dispatcher to the left.")));
- (void)releaseInterceptedContinuationContinuation:(id<WVMKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Entity_factFactEntity")))
@protocol WVMEntity_factFactEntity
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)clearWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("clear(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getWithCompletionHandler:(void (^)(id<WVMEntity_factFactEntityState> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("get(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)needToLoadForce:(BOOL)force completionHandler:(void (^)(WVMBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("needToLoad(force:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)setState:(id<WVMEntity_factFactEntityState>)state completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("set(state:completionHandler:)")));
@property (readonly) id<WVMKotlinx_coroutines_coreFlow> fact __attribute__((swift_name("fact")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Domain_factGetFactUseCaseMappers")))
@interface WVMDomain_factGetFactUseCaseMappers : WVMBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id<WVMDomain_factGetFactUseCaseStateModel>)mapEntityState:(id<WVMEntity_factFactEntityState>)entityState __attribute__((swift_name("map(entityState:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Domain_factRetrieveFactUseCaseMappers")))
@interface WVMDomain_factRetrieveFactUseCaseMappers : WVMBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id<WVMEntity_factFactEntityState>)mapRepositoryState:(WVMData_factFactRepositoryStateModel *)repositoryState __attribute__((swift_name("map(repositoryState:)")));
@end

__attribute__((swift_name("Data_factFactRepository")))
@protocol WVMData_factFactRepository
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getFactWithCompletionHandler:(void (^)(id<WVMKotlinx_coroutines_coreFlow> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getFact(completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Core_commonsDispatchers")))
@interface WVMCore_commonsDispatchers : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)dispatchers __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMCore_commonsDispatchers *shared __attribute__((swift_name("shared")));
@property (readonly) WVMKotlinx_coroutines_coreCoroutineDispatcher *data __attribute__((swift_name("data")));
@property (readonly) WVMKotlinx_coroutines_coreCoroutineDispatcher *domain __attribute__((swift_name("domain")));
@property (readonly) WVMKotlinx_coroutines_coreCoroutineDispatcher *ui __attribute__((swift_name("ui")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreKoinDefinition")))
@interface WVMKoin_coreKoinDefinition<R> : WVMBase
- (instancetype)initWithModule:(WVMKoin_coreModule *)module factory:(WVMKoin_coreInstanceFactory<R> *)factory __attribute__((swift_name("init(module:factory:)"))) __attribute__((objc_designated_initializer));
- (WVMKoin_coreKoinDefinition<R> *)doCopyModule:(WVMKoin_coreModule *)module factory:(WVMKoin_coreInstanceFactory<R> *)factory __attribute__((swift_name("doCopy(module:factory:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) WVMKoin_coreInstanceFactory<R> *factory __attribute__((swift_name("factory")));
@property (readonly) WVMKoin_coreModule *module __attribute__((swift_name("module")));
@end

__attribute__((swift_name("Koin_coreQualifier")))
@protocol WVMKoin_coreQualifier
@required
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("Koin_coreLockable")))
@interface WVMKoin_coreLockable : WVMBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreScope")))
@interface WVMKoin_coreScope : WVMKoin_coreLockable
- (instancetype)initWithScopeQualifier:(id<WVMKoin_coreQualifier>)scopeQualifier id:(NSString *)id isRoot:(BOOL)isRoot _koin:(WVMKoin_coreKoin *)_koin __attribute__((swift_name("init(scopeQualifier:id:isRoot:_koin:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (void)close __attribute__((swift_name("close()")));
- (void)declareInstance:(id _Nullable)instance qualifier:(id<WVMKoin_coreQualifier> _Nullable)qualifier secondaryTypes:(NSArray<id<WVMKotlinKClass>> *)secondaryTypes allowOverride:(BOOL)allowOverride __attribute__((swift_name("declare(instance:qualifier:secondaryTypes:allowOverride:)")));
- (id)getQualifier:(id<WVMKoin_coreQualifier> _Nullable)qualifier parameters:(WVMKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("get(qualifier:parameters:)")));
- (id _Nullable)getClazz:(id<WVMKotlinKClass>)clazz qualifier:(id<WVMKoin_coreQualifier> _Nullable)qualifier parameters:(WVMKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("get(clazz:qualifier:parameters:)")));
- (NSArray<id> *)getAll __attribute__((swift_name("getAll()")));
- (NSArray<id> *)getAllClazz:(id<WVMKotlinKClass>)clazz __attribute__((swift_name("getAll(clazz:)")));
- (WVMKoin_coreKoin *)getKoin __attribute__((swift_name("getKoin()")));
- (id _Nullable)getOrNullQualifier:(id<WVMKoin_coreQualifier> _Nullable)qualifier parameters:(WVMKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("getOrNull(qualifier:parameters:)")));
- (id _Nullable)getOrNullClazz:(id<WVMKotlinKClass>)clazz qualifier:(id<WVMKoin_coreQualifier> _Nullable)qualifier parameters:(WVMKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("getOrNull(clazz:qualifier:parameters:)")));
- (id)getPropertyKey:(NSString *)key __attribute__((swift_name("getProperty(key:)")));
- (id)getPropertyKey:(NSString *)key defaultValue:(id)defaultValue __attribute__((swift_name("getProperty(key:defaultValue:)")));
- (id _Nullable)getPropertyOrNullKey:(NSString *)key __attribute__((swift_name("getPropertyOrNull(key:)")));
- (WVMKoin_coreScope *)getScopeScopeID:(NSString *)scopeID __attribute__((swift_name("getScope(scopeID:)")));
- (id _Nullable)getSource __attribute__((swift_name("getSource()")));
- (id<WVMKotlinLazy>)injectQualifier:(id<WVMKoin_coreQualifier> _Nullable)qualifier mode:(WVMKotlinLazyThreadSafetyMode *)mode parameters:(WVMKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("inject(qualifier:mode:parameters:)")));
- (id<WVMKotlinLazy>)injectOrNullQualifier:(id<WVMKoin_coreQualifier> _Nullable)qualifier mode:(WVMKotlinLazyThreadSafetyMode *)mode parameters:(WVMKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("injectOrNull(qualifier:mode:parameters:)")));
- (BOOL)isNotClosed __attribute__((swift_name("isNotClosed()")));
- (void)linkToScopes:(WVMKotlinArray<WVMKoin_coreScope *> *)scopes __attribute__((swift_name("linkTo(scopes:)")));
- (void)registerCallbackCallback:(id<WVMKoin_coreScopeCallback>)callback __attribute__((swift_name("registerCallback(callback:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (void)unlinkScopes:(WVMKotlinArray<WVMKoin_coreScope *> *)scopes __attribute__((swift_name("unlink(scopes:)")));
@property (readonly) WVMStately_concurrencyThreadLocalRef<NSMutableArray<WVMKoin_coreParametersHolder *> *> *_parameterStackLocal __attribute__((swift_name("_parameterStackLocal")));
@property id _Nullable _source __attribute__((swift_name("_source")));
@property (readonly) BOOL closed __attribute__((swift_name("closed")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) BOOL isRoot __attribute__((swift_name("isRoot")));
@property (readonly) WVMKoin_coreLogger *logger __attribute__((swift_name("logger")));
@property (readonly) id<WVMKoin_coreQualifier> scopeQualifier __attribute__((swift_name("scopeQualifier")));
@end

__attribute__((swift_name("Koin_coreParametersHolder")))
@interface WVMKoin_coreParametersHolder : WVMBase
- (instancetype)initWith_values:(NSMutableArray<id> *)_values useIndexedValues:(WVMBoolean * _Nullable)useIndexedValues __attribute__((swift_name("init(_values:useIndexedValues:)"))) __attribute__((objc_designated_initializer));
- (WVMKoin_coreParametersHolder *)addValue:(id)value __attribute__((swift_name("add(value:)")));
- (id _Nullable)component1 __attribute__((swift_name("component1()")));
- (id _Nullable)component2 __attribute__((swift_name("component2()")));
- (id _Nullable)component3 __attribute__((swift_name("component3()")));
- (id _Nullable)component4 __attribute__((swift_name("component4()")));
- (id _Nullable)component5 __attribute__((swift_name("component5()")));
- (id _Nullable)elementAtI:(int32_t)i clazz:(id<WVMKotlinKClass>)clazz __attribute__((swift_name("elementAt(i:clazz:)")));
- (id)get __attribute__((swift_name("get()")));
- (id _Nullable)getI:(int32_t)i __attribute__((swift_name("get(i:)")));
- (id _Nullable)getOrNull __attribute__((swift_name("getOrNull()")));
- (id _Nullable)getOrNullClazz:(id<WVMKotlinKClass>)clazz __attribute__((swift_name("getOrNull(clazz:)")));
- (WVMKoin_coreParametersHolder *)insertIndex:(int32_t)index value:(id)value __attribute__((swift_name("insert(index:value:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (BOOL)isNotEmpty __attribute__((swift_name("isNotEmpty()")));
- (void)setI:(int32_t)i t:(id _Nullable)t __attribute__((swift_name("set(i:t:)")));
- (int32_t)size __attribute__((swift_name("size()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property int32_t index __attribute__((swift_name("index")));
@property (readonly) WVMBoolean * _Nullable useIndexedValues __attribute__((swift_name("useIndexedValues")));
@property (readonly) NSArray<id> *values __attribute__((swift_name("values")));
@end

__attribute__((swift_name("Koin_coreInstanceFactory")))
@interface WVMKoin_coreInstanceFactory<T> : WVMKoin_coreLockable
- (instancetype)initWithBeanDefinition:(WVMKoin_coreBeanDefinition<T> *)beanDefinition __attribute__((swift_name("init(beanDefinition:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property (class, readonly, getter=companion) WVMKoin_coreInstanceFactoryCompanion *companion __attribute__((swift_name("companion")));
- (T _Nullable)createContext:(WVMKoin_coreInstanceContext *)context __attribute__((swift_name("create(context:)")));
- (void)dropScope:(WVMKoin_coreScope * _Nullable)scope __attribute__((swift_name("drop(scope:)")));
- (void)dropAll __attribute__((swift_name("dropAll()")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (T _Nullable)getContext:(WVMKoin_coreInstanceContext *)context __attribute__((swift_name("get(context:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isCreatedContext:(WVMKoin_coreInstanceContext * _Nullable)context __attribute__((swift_name("isCreated(context:)")));
@property (readonly) WVMKoin_coreBeanDefinition<T> *beanDefinition __attribute__((swift_name("beanDefinition")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreSingleInstanceFactory")))
@interface WVMKoin_coreSingleInstanceFactory<T> : WVMKoin_coreInstanceFactory<T>
- (instancetype)initWithBeanDefinition:(WVMKoin_coreBeanDefinition<T> *)beanDefinition __attribute__((swift_name("init(beanDefinition:)"))) __attribute__((objc_designated_initializer));
- (T _Nullable)createContext:(WVMKoin_coreInstanceContext *)context __attribute__((swift_name("create(context:)")));
- (void)dropScope:(WVMKoin_coreScope * _Nullable)scope __attribute__((swift_name("drop(scope:)")));
- (void)dropAll __attribute__((swift_name("dropAll()")));
- (T _Nullable)getContext:(WVMKoin_coreInstanceContext *)context __attribute__((swift_name("get(context:)")));
- (BOOL)isCreatedContext:(WVMKoin_coreInstanceContext * _Nullable)context __attribute__((swift_name("isCreated(context:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreScopeDSL")))
@interface WVMKoin_coreScopeDSL : WVMBase
- (instancetype)initWithScopeQualifier:(id<WVMKoin_coreQualifier>)scopeQualifier module:(WVMKoin_coreModule *)module __attribute__((swift_name("init(scopeQualifier:module:)"))) __attribute__((objc_designated_initializer));
- (WVMKoin_coreKoinDefinition<id> *)factoryQualifier:(id<WVMKoin_coreQualifier> _Nullable)qualifier definition:(id _Nullable (^)(WVMKoin_coreScope *, WVMKoin_coreParametersHolder *))definition __attribute__((swift_name("factory(qualifier:definition:)")));
- (WVMKoin_coreKoinDefinition<id> *)scopedQualifier:(id<WVMKoin_coreQualifier> _Nullable)qualifier definition:(id _Nullable (^)(WVMKoin_coreScope *, WVMKoin_coreParametersHolder *))definition __attribute__((swift_name("scoped(qualifier:definition:)")));
@property (readonly) WVMKoin_coreModule *module __attribute__((swift_name("module")));
@property (readonly) id<WVMKoin_coreQualifier> scopeQualifier __attribute__((swift_name("scopeQualifier")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestData")))
@interface WVMKtor_client_coreHttpRequestData : WVMBase
- (instancetype)initWithUrl:(WVMKtor_httpUrl *)url method:(WVMKtor_httpHttpMethod *)method headers:(id<WVMKtor_httpHeaders>)headers body:(WVMKtor_httpOutgoingContent *)body executionContext:(id<WVMKotlinx_coroutines_coreJob>)executionContext attributes:(id<WVMKtor_utilsAttributes>)attributes __attribute__((swift_name("init(url:method:headers:body:executionContext:attributes:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)getCapabilityOrNullKey:(id<WVMKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<WVMKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) WVMKtor_httpOutgoingContent *body __attribute__((swift_name("body")));
@property (readonly) id<WVMKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) id<WVMKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) WVMKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) WVMKtor_httpUrl *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponseData")))
@interface WVMKtor_client_coreHttpResponseData : WVMBase
- (instancetype)initWithStatusCode:(WVMKtor_httpHttpStatusCode *)statusCode requestTime:(WVMKtor_utilsGMTDate *)requestTime headers:(id<WVMKtor_httpHeaders>)headers version:(WVMKtor_httpHttpProtocolVersion *)version body:(id)body callContext:(id<WVMKotlinCoroutineContext>)callContext __attribute__((swift_name("init(statusCode:requestTime:headers:version:body:callContext:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id body __attribute__((swift_name("body")));
@property (readonly) id<WVMKotlinCoroutineContext> callContext __attribute__((swift_name("callContext")));
@property (readonly) id<WVMKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) WVMKtor_utilsGMTDate *requestTime __attribute__((swift_name("requestTime")));
@property (readonly) WVMKtor_utilsGMTDate *responseTime __attribute__((swift_name("responseTime")));
@property (readonly) WVMKtor_httpHttpStatusCode *statusCode __attribute__((swift_name("statusCode")));
@property (readonly) WVMKtor_httpHttpProtocolVersion *version __attribute__((swift_name("version")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreProxyConfig")))
@interface WVMKtor_client_coreProxyConfig : WVMBase
- (instancetype)initWithUrl:(WVMKtor_httpUrl *)url __attribute__((swift_name("init(url:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) WVMKtor_httpUrl *url __attribute__((swift_name("url")));
@end

__attribute__((swift_name("Ktor_eventsEventDefinition")))
@interface WVMKtor_eventsEventDefinition<T> : WVMBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsPipelinePhase")))
@interface WVMKtor_utilsPipelinePhase : WVMBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((swift_name("KotlinFunction")))
@protocol WVMKotlinFunction
@required
@end

__attribute__((swift_name("KotlinSuspendFunction2")))
@protocol WVMKotlinSuspendFunction2 <WVMKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 p2:(id _Nullable)p2 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:p2:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline.Phases")))
@interface WVMKtor_client_coreHttpReceivePipelinePhases : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKtor_client_coreHttpReceivePipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) WVMKtor_utilsPipelinePhase *After __attribute__((swift_name("After")));
@property (readonly) WVMKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) WVMKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@end

__attribute__((swift_name("Ktor_httpHttpMessage")))
@protocol WVMKtor_httpHttpMessage
@required
@property (readonly) id<WVMKtor_httpHeaders> headers_ __attribute__((swift_name("headers_")));
@end

__attribute__((swift_name("Ktor_client_coreHttpResponse")))
@interface WVMKtor_client_coreHttpResponse : WVMBase <WVMKtor_httpHttpMessage, WVMKotlinx_coroutines_coreCoroutineScope>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) WVMKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));
@property (readonly) id<WVMKtor_ioByteReadChannel> content __attribute__((swift_name("content")));
@property (readonly) WVMKtor_utilsGMTDate *requestTime __attribute__((swift_name("requestTime")));
@property (readonly) WVMKtor_utilsGMTDate *responseTime __attribute__((swift_name("responseTime")));
@property (readonly) WVMKtor_httpHttpStatusCode *status __attribute__((swift_name("status")));
@property (readonly) WVMKtor_httpHttpProtocolVersion *version __attribute__((swift_name("version")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinUnit")))
@interface WVMKotlinUnit : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unit __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKotlinUnit *shared __attribute__((swift_name("shared")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline.Phases")))
@interface WVMKtor_client_coreHttpRequestPipelinePhases : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKtor_client_coreHttpRequestPipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) WVMKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) WVMKtor_utilsPipelinePhase *Render __attribute__((swift_name("Render")));
@property (readonly) WVMKtor_utilsPipelinePhase *Send __attribute__((swift_name("Send")));
@property (readonly) WVMKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@property (readonly) WVMKtor_utilsPipelinePhase *Transform __attribute__((swift_name("Transform")));
@end

__attribute__((swift_name("Ktor_httpHttpMessageBuilder")))
@protocol WVMKtor_httpHttpMessageBuilder
@required
@property (readonly) WVMKtor_httpHeadersBuilder *headers_ __attribute__((swift_name("headers_")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestBuilder")))
@interface WVMKtor_client_coreHttpRequestBuilder : WVMBase <WVMKtor_httpHttpMessageBuilder>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) WVMKtor_client_coreHttpRequestBuilderCompanion *companion __attribute__((swift_name("companion")));
- (WVMKtor_client_coreHttpRequestData *)build __attribute__((swift_name("build()")));
- (id _Nullable)getCapabilityOrNullKey:(id<WVMKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (void)setAttributesBlock:(void (^)(id<WVMKtor_utilsAttributes>))block __attribute__((swift_name("setAttributes(block:)")));
- (void)setCapabilityKey:(id<WVMKtor_client_coreHttpClientEngineCapability>)key capability:(id)capability __attribute__((swift_name("setCapability(key:capability:)")));
- (WVMKtor_client_coreHttpRequestBuilder *)takeFromBuilder:(WVMKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFrom(builder:)")));
- (WVMKtor_client_coreHttpRequestBuilder *)takeFromWithExecutionContextBuilder:(WVMKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFromWithExecutionContext(builder:)")));
- (void)urlBlock:(void (^)(WVMKtor_httpURLBuilder *, WVMKtor_httpURLBuilder *))block __attribute__((swift_name("url(block:)")));
@property (readonly) id<WVMKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property id body __attribute__((swift_name("body")));
@property WVMKtor_utilsTypeInfo * _Nullable bodyType __attribute__((swift_name("bodyType")));
@property (readonly) id<WVMKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) WVMKtor_httpHeadersBuilder *headers_ __attribute__((swift_name("headers_")));
@property WVMKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) WVMKtor_httpURLBuilder *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline.Phases")))
@interface WVMKtor_client_coreHttpResponsePipelinePhases : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKtor_client_coreHttpResponsePipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) WVMKtor_utilsPipelinePhase *After __attribute__((swift_name("After")));
@property (readonly) WVMKtor_utilsPipelinePhase *Parse __attribute__((swift_name("Parse")));
@property (readonly) WVMKtor_utilsPipelinePhase *Receive __attribute__((swift_name("Receive")));
@property (readonly) WVMKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@property (readonly) WVMKtor_utilsPipelinePhase *Transform __attribute__((swift_name("Transform")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponseContainer")))
@interface WVMKtor_client_coreHttpResponseContainer : WVMBase
- (instancetype)initWithExpectedType:(WVMKtor_utilsTypeInfo *)expectedType response:(id)response __attribute__((swift_name("init(expectedType:response:)"))) __attribute__((objc_designated_initializer));
- (WVMKtor_client_coreHttpResponseContainer *)doCopyExpectedType:(WVMKtor_utilsTypeInfo *)expectedType response:(id)response __attribute__((swift_name("doCopy(expectedType:response:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) WVMKtor_utilsTypeInfo *expectedType __attribute__((swift_name("expectedType")));
@property (readonly) id response __attribute__((swift_name("response")));
@end

__attribute__((swift_name("Ktor_client_coreHttpClientCall")))
@interface WVMKtor_client_coreHttpClientCall : WVMBase <WVMKotlinx_coroutines_coreCoroutineScope>
- (instancetype)initWithClient:(WVMKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithClient:(WVMKtor_client_coreHttpClient *)client requestData:(WVMKtor_client_coreHttpRequestData *)requestData responseData:(WVMKtor_client_coreHttpResponseData *)responseData __attribute__((swift_name("init(client:requestData:responseData:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) WVMKtor_client_coreHttpClientCallCompanion *companion __attribute__((swift_name("companion")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)bodyInfo:(WVMKtor_utilsTypeInfo *)info completionHandler:(void (^)(id _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("body(info:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)bodyNullableInfo:(WVMKtor_utilsTypeInfo *)info completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("bodyNullable(info:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)getResponseContentWithCompletionHandler:(void (^)(id<WVMKtor_ioByteReadChannel> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getResponseContent(completionHandler:)")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) BOOL allowDoubleReceive __attribute__((swift_name("allowDoubleReceive")));
@property (readonly) id<WVMKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) WVMKtor_client_coreHttpClient *client __attribute__((swift_name("client")));
@property (readonly) id<WVMKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property id<WVMKtor_client_coreHttpRequest> request __attribute__((swift_name("request")));
@property WVMKtor_client_coreHttpResponse *response __attribute__((swift_name("response")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline.Phases")))
@interface WVMKtor_client_coreHttpSendPipelinePhases : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKtor_client_coreHttpSendPipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) WVMKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) WVMKtor_utilsPipelinePhase *Engine __attribute__((swift_name("Engine")));
@property (readonly) WVMKtor_utilsPipelinePhase *Monitoring __attribute__((swift_name("Monitoring")));
@property (readonly) WVMKtor_utilsPipelinePhase *Receive __attribute__((swift_name("Receive")));
@property (readonly) WVMKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreParentJob")))
@protocol WVMKotlinx_coroutines_coreParentJob <WVMKotlinx_coroutines_coreJob>
@required
- (WVMKotlinCancellationException *)getChildJobCancellationCause __attribute__((swift_name("getChildJobCancellationCause()")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSelectInstance")))
@protocol WVMKotlinx_coroutines_coreSelectInstance
@required
- (void)disposeOnCompletionDisposableHandle:(id<WVMKotlinx_coroutines_coreDisposableHandle>)disposableHandle __attribute__((swift_name("disposeOnCompletion(disposableHandle:)")));
- (void)selectInRegistrationPhaseInternalResult:(id _Nullable)internalResult __attribute__((swift_name("selectInRegistrationPhase(internalResult:)")));
- (BOOL)trySelectClauseObject:(id)clauseObject result:(id _Nullable)result __attribute__((swift_name("trySelect(clauseObject:result:)")));
@property (readonly) id<WVMKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinContinuation")))
@protocol WVMKotlinContinuation
@required
- (void)resumeWithResult:(id _Nullable)result __attribute__((swift_name("resumeWith(result:)")));
@property (readonly) id<WVMKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
 *   kotlin.ExperimentalStdlibApi
*/
__attribute__((swift_name("KotlinAbstractCoroutineContextKey")))
@interface WVMKotlinAbstractCoroutineContextKey<B, E> : WVMBase <WVMKotlinCoroutineContextKey>
- (instancetype)initWithBaseKey:(id<WVMKotlinCoroutineContextKey>)baseKey safeCast:(E _Nullable (^)(id<WVMKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.ExperimentalStdlibApi
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher.Key")))
@interface WVMKotlinx_coroutines_coreCoroutineDispatcherKey : WVMKotlinAbstractCoroutineContextKey<id<WVMKotlinContinuationInterceptor>, WVMKotlinx_coroutines_coreCoroutineDispatcher *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithBaseKey:(id<WVMKotlinCoroutineContextKey>)baseKey safeCast:(id<WVMKotlinCoroutineContextElement> _Nullable (^)(id<WVMKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)key __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKotlinx_coroutines_coreCoroutineDispatcherKey *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreRunnable")))
@protocol WVMKotlinx_coroutines_coreRunnable
@required
- (void)run __attribute__((swift_name("run()")));
@end

__attribute__((swift_name("Entity_factFactEntityState")))
@protocol WVMEntity_factFactEntityState
@required
@end

__attribute__((swift_name("Data_factFactRepositoryStateModel")))
@interface WVMData_factFactRepositoryStateModel : WVMBase
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreKoin")))
@interface WVMKoin_coreKoin : WVMBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)close __attribute__((swift_name("close()")));
- (void)createEagerInstances __attribute__((swift_name("createEagerInstances()")));
- (WVMKoin_coreScope *)createScopeT:(id<WVMKoin_coreKoinScopeComponent>)t __attribute__((swift_name("createScope(t:)")));
- (WVMKoin_coreScope *)createScopeScopeId:(NSString *)scopeId __attribute__((swift_name("createScope(scopeId:)")));
- (WVMKoin_coreScope *)createScopeScopeId:(NSString *)scopeId source:(id _Nullable)source __attribute__((swift_name("createScope(scopeId:source:)")));
- (WVMKoin_coreScope *)createScopeScopeId:(NSString *)scopeId qualifier:(id<WVMKoin_coreQualifier>)qualifier source:(id _Nullable)source __attribute__((swift_name("createScope(scopeId:qualifier:source:)")));
- (void)declareInstance:(id _Nullable)instance qualifier:(id<WVMKoin_coreQualifier> _Nullable)qualifier secondaryTypes:(NSArray<id<WVMKotlinKClass>> *)secondaryTypes allowOverride:(BOOL)allowOverride __attribute__((swift_name("declare(instance:qualifier:secondaryTypes:allowOverride:)")));
- (void)deletePropertyKey:(NSString *)key __attribute__((swift_name("deleteProperty(key:)")));
- (void)deleteScopeScopeId:(NSString *)scopeId __attribute__((swift_name("deleteScope(scopeId:)")));
- (id)getQualifier:(id<WVMKoin_coreQualifier> _Nullable)qualifier parameters:(WVMKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("get(qualifier:parameters:)")));
- (id _Nullable)getClazz:(id<WVMKotlinKClass>)clazz qualifier:(id<WVMKoin_coreQualifier> _Nullable)qualifier parameters:(WVMKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("get(clazz:qualifier:parameters:)")));
- (NSArray<id> *)getAll __attribute__((swift_name("getAll()")));
- (WVMKoin_coreScope *)getOrCreateScopeScopeId:(NSString *)scopeId __attribute__((swift_name("getOrCreateScope(scopeId:)")));
- (WVMKoin_coreScope *)getOrCreateScopeScopeId:(NSString *)scopeId qualifier:(id<WVMKoin_coreQualifier>)qualifier source:(id _Nullable)source __attribute__((swift_name("getOrCreateScope(scopeId:qualifier:source:)")));
- (id _Nullable)getOrNullQualifier:(id<WVMKoin_coreQualifier> _Nullable)qualifier parameters:(WVMKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("getOrNull(qualifier:parameters:)")));
- (id _Nullable)getOrNullClazz:(id<WVMKotlinKClass>)clazz qualifier:(id<WVMKoin_coreQualifier> _Nullable)qualifier parameters:(WVMKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("getOrNull(clazz:qualifier:parameters:)")));
- (id _Nullable)getPropertyKey:(NSString *)key __attribute__((swift_name("getProperty(key:)")));
- (id)getPropertyKey:(NSString *)key defaultValue:(id)defaultValue __attribute__((swift_name("getProperty(key:defaultValue:)")));
- (WVMKoin_coreScope *)getScopeScopeId:(NSString *)scopeId __attribute__((swift_name("getScope(scopeId:)")));
- (WVMKoin_coreScope * _Nullable)getScopeOrNullScopeId:(NSString *)scopeId __attribute__((swift_name("getScopeOrNull(scopeId:)")));
- (id<WVMKotlinLazy>)injectQualifier:(id<WVMKoin_coreQualifier> _Nullable)qualifier mode:(WVMKotlinLazyThreadSafetyMode *)mode parameters:(WVMKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("inject(qualifier:mode:parameters:)")));
- (id<WVMKotlinLazy>)injectOrNullQualifier:(id<WVMKoin_coreQualifier> _Nullable)qualifier mode:(WVMKotlinLazyThreadSafetyMode *)mode parameters:(WVMKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("injectOrNull(qualifier:mode:parameters:)")));
- (void)loadModulesModules:(NSArray<WVMKoin_coreModule *> *)modules allowOverride:(BOOL)allowOverride createEagerInstances:(BOOL)createEagerInstances __attribute__((swift_name("loadModules(modules:allowOverride:createEagerInstances:)")));
- (void)setPropertyKey:(NSString *)key value:(id)value __attribute__((swift_name("setProperty(key:value:)")));
- (void)setupLoggerLogger:(WVMKoin_coreLogger *)logger __attribute__((swift_name("setupLogger(logger:)")));
- (void)unloadModulesModules:(NSArray<WVMKoin_coreModule *> *)modules __attribute__((swift_name("unloadModules(modules:)")));
@property (readonly) WVMKoin_coreExtensionManager *extensionManager __attribute__((swift_name("extensionManager")));
@property (readonly) WVMKoin_coreInstanceRegistry *instanceRegistry __attribute__((swift_name("instanceRegistry")));
@property (readonly) WVMKoin_coreLogger *logger __attribute__((swift_name("logger")));
@property (readonly) WVMKoin_corePropertyRegistry *propertyRegistry __attribute__((swift_name("propertyRegistry")));
@property (readonly) WVMKoin_coreScopeRegistry *scopeRegistry __attribute__((swift_name("scopeRegistry")));
@end

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol WVMKotlinKDeclarationContainer
@required
@end

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol WVMKotlinKAnnotatedElement
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((swift_name("KotlinKClassifier")))
@protocol WVMKotlinKClassifier
@required
@end

__attribute__((swift_name("KotlinKClass")))
@protocol WVMKotlinKClass <WVMKotlinKDeclarationContainer, WVMKotlinKAnnotatedElement, WVMKotlinKClassifier>
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end

__attribute__((swift_name("KotlinLazy")))
@protocol WVMKotlinLazy
@required
- (BOOL)isInitialized __attribute__((swift_name("isInitialized()")));
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinLazyThreadSafetyMode")))
@interface WVMKotlinLazyThreadSafetyMode : WVMKotlinEnum<WVMKotlinLazyThreadSafetyMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) WVMKotlinLazyThreadSafetyMode *synchronized __attribute__((swift_name("synchronized")));
@property (class, readonly) WVMKotlinLazyThreadSafetyMode *publication __attribute__((swift_name("publication")));
@property (class, readonly) WVMKotlinLazyThreadSafetyMode *none __attribute__((swift_name("none")));
+ (WVMKotlinArray<WVMKotlinLazyThreadSafetyMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<WVMKotlinLazyThreadSafetyMode *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("Koin_coreScopeCallback")))
@protocol WVMKoin_coreScopeCallback
@required
- (void)onScopeCloseScope:(WVMKoin_coreScope *)scope __attribute__((swift_name("onScopeClose(scope:)")));
@end

__attribute__((swift_name("Stately_concurrencyThreadLocalRef")))
@interface WVMStately_concurrencyThreadLocalRef<T> : WVMBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (T _Nullable)get __attribute__((swift_name("get()")));
- (void)remove __attribute__((swift_name("remove()")));
- (void)setValue:(T _Nullable)value __attribute__((swift_name("set(value:)")));
@end

__attribute__((swift_name("Koin_coreLogger")))
@interface WVMKoin_coreLogger : WVMBase
- (instancetype)initWithLevel:(WVMKoin_coreLevel *)level __attribute__((swift_name("init(level:)"))) __attribute__((objc_designated_initializer));
- (void)debugMsg:(NSString *)msg __attribute__((swift_name("debug(msg:)")));
- (void)displayLevel:(WVMKoin_coreLevel *)level msg:(NSString *)msg __attribute__((swift_name("display(level:msg:)")));
- (void)errorMsg:(NSString *)msg __attribute__((swift_name("error(msg:)")));
- (void)infoMsg:(NSString *)msg __attribute__((swift_name("info(msg:)")));
- (BOOL)isAtLvl:(WVMKoin_coreLevel *)lvl __attribute__((swift_name("isAt(lvl:)")));
- (void)logLvl:(WVMKoin_coreLevel *)lvl msg:(NSString *(^)(void))msg __attribute__((swift_name("log(lvl:msg:)")));
- (void)logLvl:(WVMKoin_coreLevel *)lvl msg_:(NSString *)msg __attribute__((swift_name("log(lvl:msg_:)")));
- (void)warnMsg:(NSString *)msg __attribute__((swift_name("warn(msg:)")));
@property WVMKoin_coreLevel *level __attribute__((swift_name("level")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreBeanDefinition")))
@interface WVMKoin_coreBeanDefinition<T> : WVMBase
- (instancetype)initWithScopeQualifier:(id<WVMKoin_coreQualifier>)scopeQualifier primaryType:(id<WVMKotlinKClass>)primaryType qualifier:(id<WVMKoin_coreQualifier> _Nullable)qualifier definition:(T _Nullable (^)(WVMKoin_coreScope *, WVMKoin_coreParametersHolder *))definition kind:(WVMKoin_coreKind *)kind secondaryTypes:(NSArray<id<WVMKotlinKClass>> *)secondaryTypes __attribute__((swift_name("init(scopeQualifier:primaryType:qualifier:definition:kind:secondaryTypes:)"))) __attribute__((objc_designated_initializer));
- (WVMKoin_coreBeanDefinition<T> *)doCopyScopeQualifier:(id<WVMKoin_coreQualifier>)scopeQualifier primaryType:(id<WVMKotlinKClass>)primaryType qualifier:(id<WVMKoin_coreQualifier> _Nullable)qualifier definition:(T _Nullable (^)(WVMKoin_coreScope *, WVMKoin_coreParametersHolder *))definition kind:(WVMKoin_coreKind *)kind secondaryTypes:(NSArray<id<WVMKotlinKClass>> *)secondaryTypes __attribute__((swift_name("doCopy(scopeQualifier:primaryType:qualifier:definition:kind:secondaryTypes:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (BOOL)hasTypeClazz:(id<WVMKotlinKClass>)clazz __attribute__((swift_name("hasType(clazz:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isClazz:(id<WVMKotlinKClass>)clazz qualifier:(id<WVMKoin_coreQualifier> _Nullable)qualifier scopeDefinition:(id<WVMKoin_coreQualifier>)scopeDefinition __attribute__((swift_name("is(clazz:qualifier:scopeDefinition:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property WVMKoin_coreCallbacks<T> *callbacks __attribute__((swift_name("callbacks")));
@property (readonly) T _Nullable (^definition)(WVMKoin_coreScope *, WVMKoin_coreParametersHolder *) __attribute__((swift_name("definition")));
@property (readonly) WVMKoin_coreKind *kind __attribute__((swift_name("kind")));
@property (readonly) id<WVMKotlinKClass> primaryType __attribute__((swift_name("primaryType")));
@property id<WVMKoin_coreQualifier> _Nullable qualifier __attribute__((swift_name("qualifier")));
@property (readonly) id<WVMKoin_coreQualifier> scopeQualifier __attribute__((swift_name("scopeQualifier")));
@property NSArray<id<WVMKotlinKClass>> *secondaryTypes __attribute__((swift_name("secondaryTypes")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreInstanceFactoryCompanion")))
@interface WVMKoin_coreInstanceFactoryCompanion : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKoin_coreInstanceFactoryCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *ERROR_SEPARATOR __attribute__((swift_name("ERROR_SEPARATOR")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreInstanceContext")))
@interface WVMKoin_coreInstanceContext : WVMBase
- (instancetype)initWithLogger:(WVMKoin_coreLogger *)logger scope:(WVMKoin_coreScope *)scope parameters:(WVMKoin_coreParametersHolder * _Nullable)parameters __attribute__((swift_name("init(logger:scope:parameters:)"))) __attribute__((objc_designated_initializer));
@property (readonly) WVMKoin_coreLogger *logger __attribute__((swift_name("logger")));
@property (readonly) WVMKoin_coreParametersHolder * _Nullable parameters __attribute__((swift_name("parameters")));
@property (readonly) WVMKoin_coreScope *scope __attribute__((swift_name("scope")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl")))
@interface WVMKtor_httpUrl : WVMBase
@property (class, readonly, getter=companion) WVMKtor_httpUrlCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *encodedFragment __attribute__((swift_name("encodedFragment")));
@property (readonly) NSString * _Nullable encodedPassword __attribute__((swift_name("encodedPassword")));
@property (readonly) NSString *encodedPath __attribute__((swift_name("encodedPath")));
@property (readonly) NSString *encodedPathAndQuery __attribute__((swift_name("encodedPathAndQuery")));
@property (readonly) NSString *encodedQuery __attribute__((swift_name("encodedQuery")));
@property (readonly) NSString * _Nullable encodedUser __attribute__((swift_name("encodedUser")));
@property (readonly) NSString *fragment __attribute__((swift_name("fragment")));
@property (readonly) NSString *host __attribute__((swift_name("host")));
@property (readonly) id<WVMKtor_httpParameters> parameters __attribute__((swift_name("parameters")));
@property (readonly) NSString * _Nullable password __attribute__((swift_name("password")));
@property (readonly) NSArray<NSString *> *pathSegments __attribute__((swift_name("pathSegments")));
@property (readonly) int32_t port __attribute__((swift_name("port")));
@property (readonly) WVMKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property (readonly) int32_t specifiedPort __attribute__((swift_name("specifiedPort")));
@property (readonly) BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property (readonly) NSString * _Nullable user __attribute__((swift_name("user")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpMethod")))
@interface WVMKtor_httpHttpMethod : WVMBase
- (instancetype)initWithValue:(NSString *)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) WVMKtor_httpHttpMethodCompanion *companion __attribute__((swift_name("companion")));
- (WVMKtor_httpHttpMethod *)doCopyValue:(NSString *)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("Ktor_utilsStringValues")))
@protocol WVMKtor_utilsStringValues
@required
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<WVMKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (void)forEachBody:(void (^)(NSString *, NSArray<NSString *> *))body __attribute__((swift_name("forEach(body:)")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty_ __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@end

__attribute__((swift_name("Ktor_httpHeaders")))
@protocol WVMKtor_httpHeaders <WVMKtor_utilsStringValues>
@required
@end

__attribute__((swift_name("Ktor_httpOutgoingContent")))
@interface WVMKtor_httpOutgoingContent : WVMBase
- (id _Nullable)getPropertyKey:(WVMKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getProperty(key:)")));
- (void)setPropertyKey:(WVMKtor_utilsAttributeKey<id> *)key value:(id _Nullable)value __attribute__((swift_name("setProperty(key:value:)")));
- (id<WVMKtor_httpHeaders> _Nullable)trailers __attribute__((swift_name("trailers()")));
@property (readonly) WVMLong * _Nullable contentLength __attribute__((swift_name("contentLength")));
@property (readonly) WVMKtor_httpContentType * _Nullable contentType __attribute__((swift_name("contentType")));
@property (readonly) id<WVMKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) WVMKtor_httpHttpStatusCode * _Nullable status __attribute__((swift_name("status")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpStatusCode")))
@interface WVMKtor_httpHttpStatusCode : WVMBase <WVMKotlinComparable>
- (instancetype)initWithValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("init(value:description:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) WVMKtor_httpHttpStatusCodeCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(WVMKtor_httpHttpStatusCode *)other __attribute__((swift_name("compareTo(other:)")));
- (WVMKtor_httpHttpStatusCode *)doCopyValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("doCopy(value:description:)")));
- (WVMKtor_httpHttpStatusCode *)descriptionValue:(NSString *)value __attribute__((swift_name("description(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *description_ __attribute__((swift_name("description_")));
@property (readonly) int32_t value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsGMTDate")))
@interface WVMKtor_utilsGMTDate : WVMBase <WVMKotlinComparable>
@property (class, readonly, getter=companion) WVMKtor_utilsGMTDateCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(WVMKtor_utilsGMTDate *)other __attribute__((swift_name("compareTo(other:)")));
- (WVMKtor_utilsGMTDate *)doCopySeconds:(int32_t)seconds minutes:(int32_t)minutes hours:(int32_t)hours dayOfWeek:(WVMKtor_utilsWeekDay *)dayOfWeek dayOfMonth:(int32_t)dayOfMonth dayOfYear:(int32_t)dayOfYear month:(WVMKtor_utilsMonth *)month year:(int32_t)year timestamp:(int64_t)timestamp __attribute__((swift_name("doCopy(seconds:minutes:hours:dayOfWeek:dayOfMonth:dayOfYear:month:year:timestamp:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t dayOfMonth __attribute__((swift_name("dayOfMonth")));
@property (readonly) WVMKtor_utilsWeekDay *dayOfWeek __attribute__((swift_name("dayOfWeek")));
@property (readonly) int32_t dayOfYear __attribute__((swift_name("dayOfYear")));
@property (readonly) int32_t hours __attribute__((swift_name("hours")));
@property (readonly) int32_t minutes __attribute__((swift_name("minutes")));
@property (readonly) WVMKtor_utilsMonth *month __attribute__((swift_name("month")));
@property (readonly) int32_t seconds __attribute__((swift_name("seconds")));
@property (readonly) int64_t timestamp __attribute__((swift_name("timestamp")));
@property (readonly) int32_t year __attribute__((swift_name("year")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpProtocolVersion")))
@interface WVMKtor_httpHttpProtocolVersion : WVMBase
- (instancetype)initWithName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("init(name:major:minor:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) WVMKtor_httpHttpProtocolVersionCompanion *companion __attribute__((swift_name("companion")));
- (WVMKtor_httpHttpProtocolVersion *)doCopyName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("doCopy(name:major:minor:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t major __attribute__((swift_name("major")));
@property (readonly) int32_t minor __attribute__((swift_name("minor")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((swift_name("Ktor_ioByteReadChannel")))
@protocol WVMKtor_ioByteReadChannel
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)awaitContentWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("awaitContent(completionHandler:)")));
- (BOOL)cancelCause_:(WVMKotlinThrowable * _Nullable)cause __attribute__((swift_name("cancel(cause_:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)discardMax:(int64_t)max completionHandler:(void (^)(WVMLong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("discard(max:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)peekToDestination:(WVMKtor_ioMemory *)destination destinationOffset:(int64_t)destinationOffset offset:(int64_t)offset min:(int64_t)min max:(int64_t)max completionHandler:(void (^)(WVMLong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("peekTo(destination:destinationOffset:offset:min:max:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(WVMKtor_ioChunkBuffer *)dst completionHandler:(void (^)(WVMInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:completionHandler:)")));
- (int32_t)readAvailableMin:(int32_t)min block:(void (^)(WVMKtor_ioBuffer *))block __attribute__((swift_name("readAvailable(min:block:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(WVMKotlinByteArray *)dst offset:(int32_t)offset length:(int32_t)length completionHandler:(void (^)(WVMInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:offset:length:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(void *)dst offset:(int32_t)offset length:(int32_t)length completionHandler_:(void (^)(WVMInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:offset:length:completionHandler_:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(void *)dst offset:(int64_t)offset length:(int64_t)length completionHandler__:(void (^)(WVMInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:offset:length:completionHandler__:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readBooleanWithCompletionHandler:(void (^)(WVMBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readBoolean(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readByteWithCompletionHandler:(void (^)(WVMByte * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readByte(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readDoubleWithCompletionHandler:(void (^)(WVMDouble * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readDouble(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFloatWithCompletionHandler:(void (^)(WVMFloat * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readFloat(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(WVMKtor_ioChunkBuffer *)dst n:(int32_t)n completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:n:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(WVMKotlinByteArray *)dst offset:(int32_t)offset length:(int32_t)length completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:offset:length:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(void *)dst offset:(int32_t)offset length:(int32_t)length completionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:offset:length:completionHandler_:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(void *)dst offset:(int64_t)offset length:(int64_t)length completionHandler__:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:offset:length:completionHandler__:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readIntWithCompletionHandler:(void (^)(WVMInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readInt(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readLongWithCompletionHandler:(void (^)(WVMLong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readLong(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readPacketSize:(int32_t)size completionHandler:(void (^)(WVMKtor_ioByteReadPacket * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readPacket(size:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readRemainingLimit:(int64_t)limit completionHandler:(void (^)(WVMKtor_ioByteReadPacket * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readRemaining(limit:completionHandler:)")));
- (void)readSessionConsumer:(void (^)(id<WVMKtor_ioReadSession>))consumer __attribute__((swift_name("readSession(consumer:)"))) __attribute__((deprecated("Use read { } instead.")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readShortWithCompletionHandler:(void (^)(WVMShort * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readShort(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readSuspendableSessionConsumer:(id<WVMKotlinSuspendFunction1>)consumer completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("readSuspendableSession(consumer:completionHandler:)"))) __attribute__((deprecated("Use read { } instead.")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readUTF8LineLimit:(int32_t)limit completionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("readUTF8Line(limit:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readUTF8LineToOut:(id<WVMKotlinAppendable>)out limit:(int32_t)limit completionHandler:(void (^)(WVMBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readUTF8LineTo(out:limit:completionHandler:)")));
@property (readonly) int32_t availableForRead __attribute__((swift_name("availableForRead")));
@property (readonly) WVMKotlinThrowable * _Nullable closedCause __attribute__((swift_name("closedCause")));
@property (readonly) BOOL isClosedForRead __attribute__((swift_name("isClosedForRead")));
@property (readonly) BOOL isClosedForWrite __attribute__((swift_name("isClosedForWrite")));
@property (readonly) int64_t totalBytesRead __attribute__((swift_name("totalBytesRead")));
@end

__attribute__((swift_name("Ktor_utilsStringValuesBuilder")))
@protocol WVMKtor_utilsStringValuesBuilder
@required
- (void)appendName:(NSString *)name value:(NSString *)value __attribute__((swift_name("append(name:value:)")));
- (void)appendAllStringValues:(id<WVMKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendAll(stringValues:)")));
- (void)appendAllName:(NSString *)name values:(id)values __attribute__((swift_name("appendAll(name:values:)")));
- (void)appendMissingStringValues:(id<WVMKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendMissing(stringValues:)")));
- (void)appendMissingName:(NSString *)name values:(id)values __attribute__((swift_name("appendMissing(name:values:)")));
- (id<WVMKtor_utilsStringValues>)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<WVMKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty_ __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
- (void)removeName:(NSString *)name __attribute__((swift_name("remove(name:)")));
- (BOOL)removeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("remove(name:value:)")));
- (void)removeKeysWithNoEntries __attribute__((swift_name("removeKeysWithNoEntries()")));
- (void)setName:(NSString *)name value:(NSString *)value __attribute__((swift_name("set(name:value:)")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@end

__attribute__((swift_name("Ktor_utilsStringValuesBuilderImpl")))
@interface WVMKtor_utilsStringValuesBuilderImpl : WVMBase <WVMKtor_utilsStringValuesBuilder>
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer));
- (void)appendName:(NSString *)name value:(NSString *)value __attribute__((swift_name("append(name:value:)")));
- (void)appendAllStringValues:(id<WVMKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendAll(stringValues:)")));
- (void)appendAllName:(NSString *)name values:(id)values __attribute__((swift_name("appendAll(name:values:)")));
- (void)appendMissingStringValues:(id<WVMKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendMissing(stringValues:)")));
- (void)appendMissingName:(NSString *)name values:(id)values __attribute__((swift_name("appendMissing(name:values:)")));
- (id<WVMKtor_utilsStringValues>)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<WVMKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty_ __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
- (void)removeName:(NSString *)name __attribute__((swift_name("remove(name:)")));
- (BOOL)removeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("remove(name:value:)")));
- (void)removeKeysWithNoEntries __attribute__((swift_name("removeKeysWithNoEntries()")));
- (void)setName:(NSString *)name value:(NSString *)value __attribute__((swift_name("set(name:value:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) WVMMutableDictionary<NSString *, NSMutableArray<NSString *> *> *values __attribute__((swift_name("values")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeadersBuilder")))
@interface WVMKtor_httpHeadersBuilder : WVMKtor_utilsStringValuesBuilderImpl
- (instancetype)initWithSize:(int32_t)size __attribute__((swift_name("init(size:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (id<WVMKtor_httpHeaders>)build __attribute__((swift_name("build()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestBuilder.Companion")))
@interface WVMKtor_client_coreHttpRequestBuilderCompanion : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKtor_client_coreHttpRequestBuilderCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLBuilder")))
@interface WVMKtor_httpURLBuilder : WVMBase
- (instancetype)initWithProtocol:(WVMKtor_httpURLProtocol *)protocol host:(NSString *)host port:(int32_t)port user:(NSString * _Nullable)user password:(NSString * _Nullable)password pathSegments:(NSArray<NSString *> *)pathSegments parameters:(id<WVMKtor_httpParameters>)parameters fragment:(NSString *)fragment trailingQuery:(BOOL)trailingQuery __attribute__((swift_name("init(protocol:host:port:user:password:pathSegments:parameters:fragment:trailingQuery:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) WVMKtor_httpURLBuilderCompanion *companion __attribute__((swift_name("companion")));
- (WVMKtor_httpUrl *)build __attribute__((swift_name("build()")));
- (NSString *)buildString __attribute__((swift_name("buildString()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *encodedFragment __attribute__((swift_name("encodedFragment")));
@property id<WVMKtor_httpParametersBuilder> encodedParameters __attribute__((swift_name("encodedParameters")));
@property NSString * _Nullable encodedPassword __attribute__((swift_name("encodedPassword")));
@property NSArray<NSString *> *encodedPathSegments __attribute__((swift_name("encodedPathSegments")));
@property NSString * _Nullable encodedUser __attribute__((swift_name("encodedUser")));
@property NSString *fragment __attribute__((swift_name("fragment")));
@property NSString *host __attribute__((swift_name("host")));
@property (readonly) id<WVMKtor_httpParametersBuilder> parameters __attribute__((swift_name("parameters")));
@property NSString * _Nullable password __attribute__((swift_name("password")));
@property NSArray<NSString *> *pathSegments __attribute__((swift_name("pathSegments")));
@property int32_t port __attribute__((swift_name("port")));
@property WVMKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property NSString * _Nullable user __attribute__((swift_name("user")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsTypeInfo")))
@interface WVMKtor_utilsTypeInfo : WVMBase
- (instancetype)initWithType:(id<WVMKotlinKClass>)type reifiedType:(id<WVMKotlinKType>)reifiedType kotlinType:(id<WVMKotlinKType> _Nullable)kotlinType __attribute__((swift_name("init(type:reifiedType:kotlinType:)"))) __attribute__((objc_designated_initializer));
- (WVMKtor_utilsTypeInfo *)doCopyType:(id<WVMKotlinKClass>)type reifiedType:(id<WVMKotlinKType>)reifiedType kotlinType:(id<WVMKotlinKType> _Nullable)kotlinType __attribute__((swift_name("doCopy(type:reifiedType:kotlinType:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<WVMKotlinKType> _Nullable kotlinType __attribute__((swift_name("kotlinType")));
@property (readonly) id<WVMKotlinKType> reifiedType __attribute__((swift_name("reifiedType")));
@property (readonly) id<WVMKotlinKClass> type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientCall.Companion")))
@interface WVMKtor_client_coreHttpClientCallCompanion : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKtor_client_coreHttpClientCallCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) WVMKtor_utilsAttributeKey<id> *CustomResponse __attribute__((swift_name("CustomResponse"))) __attribute__((unavailable("This is going to be removed. Please file a ticket with clarification why and what for do you need it.")));
@end

__attribute__((swift_name("Ktor_client_coreHttpRequest")))
@protocol WVMKtor_client_coreHttpRequest <WVMKtor_httpHttpMessage, WVMKotlinx_coroutines_coreCoroutineScope>
@required
@property (readonly) id<WVMKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) WVMKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));
@property (readonly) WVMKtor_httpOutgoingContent *content __attribute__((swift_name("content")));
@property (readonly) WVMKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) WVMKtor_httpUrl *url __attribute__((swift_name("url")));
@end

__attribute__((swift_name("Koin_coreKoinComponent")))
@protocol WVMKoin_coreKoinComponent
@required
- (WVMKoin_coreKoin *)getKoin __attribute__((swift_name("getKoin()")));
@end

__attribute__((swift_name("Koin_coreKoinScopeComponent")))
@protocol WVMKoin_coreKoinScopeComponent <WVMKoin_coreKoinComponent>
@required
- (void)closeScope __attribute__((swift_name("closeScope()"))) __attribute__((deprecated("not used internaly anymore")));
@property (readonly) WVMKoin_coreScope *scope __attribute__((swift_name("scope")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreExtensionManager")))
@interface WVMKoin_coreExtensionManager : WVMBase
- (instancetype)initWith_koin:(WVMKoin_coreKoin *)_koin __attribute__((swift_name("init(_koin:)"))) __attribute__((objc_designated_initializer));
- (void)close __attribute__((swift_name("close()")));
- (id<WVMKoin_coreKoinExtension>)getExtensionId:(NSString *)id __attribute__((swift_name("getExtension(id:)")));
- (id<WVMKoin_coreKoinExtension> _Nullable)getExtensionOrNullId:(NSString *)id __attribute__((swift_name("getExtensionOrNull(id:)")));
- (void)registerExtensionId:(NSString *)id extension:(id<WVMKoin_coreKoinExtension>)extension __attribute__((swift_name("registerExtension(id:extension:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreInstanceRegistry")))
@interface WVMKoin_coreInstanceRegistry : WVMBase
- (instancetype)initWith_koin:(WVMKoin_coreKoin *)_koin __attribute__((swift_name("init(_koin:)"))) __attribute__((objc_designated_initializer));
- (void)saveMappingAllowOverride:(BOOL)allowOverride mapping:(NSString *)mapping factory:(WVMKoin_coreInstanceFactory<id> *)factory logWarning:(BOOL)logWarning __attribute__((swift_name("saveMapping(allowOverride:mapping:factory:logWarning:)")));
- (int32_t)size __attribute__((swift_name("size()")));
@property (readonly) WVMKoin_coreKoin *_koin __attribute__((swift_name("_koin")));
@property (readonly) NSDictionary<NSString *, WVMKoin_coreInstanceFactory<id> *> *instances __attribute__((swift_name("instances")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_corePropertyRegistry")))
@interface WVMKoin_corePropertyRegistry : WVMBase
- (instancetype)initWith_koin:(WVMKoin_coreKoin *)_koin __attribute__((swift_name("init(_koin:)"))) __attribute__((objc_designated_initializer));
- (void)close __attribute__((swift_name("close()")));
- (void)deletePropertyKey:(NSString *)key __attribute__((swift_name("deleteProperty(key:)")));
- (id _Nullable)getPropertyKey:(NSString *)key __attribute__((swift_name("getProperty(key:)")));
- (void)savePropertiesProperties:(NSDictionary<NSString *, id> *)properties __attribute__((swift_name("saveProperties(properties:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreScopeRegistry")))
@interface WVMKoin_coreScopeRegistry : WVMBase
- (instancetype)initWith_koin:(WVMKoin_coreKoin *)_koin __attribute__((swift_name("init(_koin:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) WVMKoin_coreScopeRegistryCompanion *companion __attribute__((swift_name("companion")));
- (void)loadScopesModules:(NSSet<WVMKoin_coreModule *> *)modules __attribute__((swift_name("loadScopes(modules:)")));
@property (readonly) WVMKoin_coreScope *rootScope __attribute__((swift_name("rootScope")));
@property (readonly) NSSet<id<WVMKoin_coreQualifier>> *scopeDefinitions __attribute__((swift_name("scopeDefinitions")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreLevel")))
@interface WVMKoin_coreLevel : WVMKotlinEnum<WVMKoin_coreLevel *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) WVMKoin_coreLevel *debug __attribute__((swift_name("debug")));
@property (class, readonly) WVMKoin_coreLevel *info __attribute__((swift_name("info")));
@property (class, readonly) WVMKoin_coreLevel *warning __attribute__((swift_name("warning")));
@property (class, readonly) WVMKoin_coreLevel *error __attribute__((swift_name("error")));
@property (class, readonly) WVMKoin_coreLevel *none __attribute__((swift_name("none")));
+ (WVMKotlinArray<WVMKoin_coreLevel *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<WVMKoin_coreLevel *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreKind")))
@interface WVMKoin_coreKind : WVMKotlinEnum<WVMKoin_coreKind *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) WVMKoin_coreKind *singleton __attribute__((swift_name("singleton")));
@property (class, readonly) WVMKoin_coreKind *factory __attribute__((swift_name("factory")));
@property (class, readonly) WVMKoin_coreKind *scoped __attribute__((swift_name("scoped")));
+ (WVMKotlinArray<WVMKoin_coreKind *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<WVMKoin_coreKind *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreCallbacks")))
@interface WVMKoin_coreCallbacks<T> : WVMBase
- (instancetype)initWithOnClose:(void (^ _Nullable)(T _Nullable))onClose __attribute__((swift_name("init(onClose:)"))) __attribute__((objc_designated_initializer));
- (WVMKoin_coreCallbacks<T> *)doCopyOnClose:(void (^ _Nullable)(T _Nullable))onClose __attribute__((swift_name("doCopy(onClose:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) void (^ _Nullable onClose)(T _Nullable) __attribute__((swift_name("onClose")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl.Companion")))
@interface WVMKtor_httpUrlCompanion : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKtor_httpUrlCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Ktor_httpParameters")))
@protocol WVMKtor_httpParameters <WVMKtor_utilsStringValues>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol")))
@interface WVMKtor_httpURLProtocol : WVMBase
- (instancetype)initWithName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("init(name:defaultPort:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) WVMKtor_httpURLProtocolCompanion *companion __attribute__((swift_name("companion")));
- (WVMKtor_httpURLProtocol *)doCopyName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("doCopy(name:defaultPort:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t defaultPort __attribute__((swift_name("defaultPort")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpMethod.Companion")))
@interface WVMKtor_httpHttpMethodCompanion : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKtor_httpHttpMethodCompanion *shared __attribute__((swift_name("shared")));
- (WVMKtor_httpHttpMethod *)parseMethod:(NSString *)method __attribute__((swift_name("parse(method:)")));
@property (readonly) NSArray<WVMKtor_httpHttpMethod *> *DefaultMethods __attribute__((swift_name("DefaultMethods")));
@property (readonly) WVMKtor_httpHttpMethod *Delete __attribute__((swift_name("Delete")));
@property (readonly) WVMKtor_httpHttpMethod *Get __attribute__((swift_name("Get")));
@property (readonly) WVMKtor_httpHttpMethod *Head __attribute__((swift_name("Head")));
@property (readonly) WVMKtor_httpHttpMethod *Options __attribute__((swift_name("Options")));
@property (readonly) WVMKtor_httpHttpMethod *Patch __attribute__((swift_name("Patch")));
@property (readonly) WVMKtor_httpHttpMethod *Post __attribute__((swift_name("Post")));
@property (readonly) WVMKtor_httpHttpMethod *Put __attribute__((swift_name("Put")));
@end

__attribute__((swift_name("KotlinMapEntry")))
@protocol WVMKotlinMapEntry
@required
@property (readonly) id _Nullable key __attribute__((swift_name("key")));
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("Ktor_httpHeaderValueWithParameters")))
@interface WVMKtor_httpHeaderValueWithParameters : WVMBase
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<WVMKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) WVMKtor_httpHeaderValueWithParametersCompanion *companion __attribute__((swift_name("companion")));
- (NSString * _Nullable)parameterName:(NSString *)name __attribute__((swift_name("parameter(name:)")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) NSString *content __attribute__((swift_name("content")));
@property (readonly) NSArray<WVMKtor_httpHeaderValueParam *> *parameters __attribute__((swift_name("parameters")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpContentType")))
@interface WVMKtor_httpContentType : WVMKtor_httpHeaderValueWithParameters
- (instancetype)initWithContentType:(NSString *)contentType contentSubtype:(NSString *)contentSubtype parameters:(NSArray<WVMKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(contentType:contentSubtype:parameters:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<WVMKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) WVMKtor_httpContentTypeCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)matchPattern:(WVMKtor_httpContentType *)pattern __attribute__((swift_name("match(pattern:)")));
- (BOOL)matchPattern_:(NSString *)pattern __attribute__((swift_name("match(pattern_:)")));
- (WVMKtor_httpContentType *)withParameterName:(NSString *)name value:(NSString *)value __attribute__((swift_name("withParameter(name:value:)")));
- (WVMKtor_httpContentType *)withoutParameters __attribute__((swift_name("withoutParameters()")));
@property (readonly) NSString *contentSubtype __attribute__((swift_name("contentSubtype")));
@property (readonly) NSString *contentType __attribute__((swift_name("contentType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpStatusCode.Companion")))
@interface WVMKtor_httpHttpStatusCodeCompanion : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKtor_httpHttpStatusCodeCompanion *shared __attribute__((swift_name("shared")));
- (WVMKtor_httpHttpStatusCode *)fromValueValue:(int32_t)value __attribute__((swift_name("fromValue(value:)")));
@property (readonly) WVMKtor_httpHttpStatusCode *Accepted __attribute__((swift_name("Accepted")));
@property (readonly) WVMKtor_httpHttpStatusCode *BadGateway __attribute__((swift_name("BadGateway")));
@property (readonly) WVMKtor_httpHttpStatusCode *BadRequest __attribute__((swift_name("BadRequest")));
@property (readonly) WVMKtor_httpHttpStatusCode *Conflict __attribute__((swift_name("Conflict")));
@property (readonly) WVMKtor_httpHttpStatusCode *Continue __attribute__((swift_name("Continue")));
@property (readonly) WVMKtor_httpHttpStatusCode *Created __attribute__((swift_name("Created")));
@property (readonly) WVMKtor_httpHttpStatusCode *ExpectationFailed __attribute__((swift_name("ExpectationFailed")));
@property (readonly) WVMKtor_httpHttpStatusCode *FailedDependency __attribute__((swift_name("FailedDependency")));
@property (readonly) WVMKtor_httpHttpStatusCode *Forbidden __attribute__((swift_name("Forbidden")));
@property (readonly) WVMKtor_httpHttpStatusCode *Found __attribute__((swift_name("Found")));
@property (readonly) WVMKtor_httpHttpStatusCode *GatewayTimeout __attribute__((swift_name("GatewayTimeout")));
@property (readonly) WVMKtor_httpHttpStatusCode *Gone __attribute__((swift_name("Gone")));
@property (readonly) WVMKtor_httpHttpStatusCode *InsufficientStorage __attribute__((swift_name("InsufficientStorage")));
@property (readonly) WVMKtor_httpHttpStatusCode *InternalServerError __attribute__((swift_name("InternalServerError")));
@property (readonly) WVMKtor_httpHttpStatusCode *LengthRequired __attribute__((swift_name("LengthRequired")));
@property (readonly) WVMKtor_httpHttpStatusCode *Locked __attribute__((swift_name("Locked")));
@property (readonly) WVMKtor_httpHttpStatusCode *MethodNotAllowed __attribute__((swift_name("MethodNotAllowed")));
@property (readonly) WVMKtor_httpHttpStatusCode *MovedPermanently __attribute__((swift_name("MovedPermanently")));
@property (readonly) WVMKtor_httpHttpStatusCode *MultiStatus __attribute__((swift_name("MultiStatus")));
@property (readonly) WVMKtor_httpHttpStatusCode *MultipleChoices __attribute__((swift_name("MultipleChoices")));
@property (readonly) WVMKtor_httpHttpStatusCode *NoContent __attribute__((swift_name("NoContent")));
@property (readonly) WVMKtor_httpHttpStatusCode *NonAuthoritativeInformation __attribute__((swift_name("NonAuthoritativeInformation")));
@property (readonly) WVMKtor_httpHttpStatusCode *NotAcceptable __attribute__((swift_name("NotAcceptable")));
@property (readonly) WVMKtor_httpHttpStatusCode *NotFound __attribute__((swift_name("NotFound")));
@property (readonly) WVMKtor_httpHttpStatusCode *NotImplemented __attribute__((swift_name("NotImplemented")));
@property (readonly) WVMKtor_httpHttpStatusCode *NotModified __attribute__((swift_name("NotModified")));
@property (readonly) WVMKtor_httpHttpStatusCode *OK __attribute__((swift_name("OK")));
@property (readonly) WVMKtor_httpHttpStatusCode *PartialContent __attribute__((swift_name("PartialContent")));
@property (readonly) WVMKtor_httpHttpStatusCode *PayloadTooLarge __attribute__((swift_name("PayloadTooLarge")));
@property (readonly) WVMKtor_httpHttpStatusCode *PaymentRequired __attribute__((swift_name("PaymentRequired")));
@property (readonly) WVMKtor_httpHttpStatusCode *PermanentRedirect __attribute__((swift_name("PermanentRedirect")));
@property (readonly) WVMKtor_httpHttpStatusCode *PreconditionFailed __attribute__((swift_name("PreconditionFailed")));
@property (readonly) WVMKtor_httpHttpStatusCode *Processing __attribute__((swift_name("Processing")));
@property (readonly) WVMKtor_httpHttpStatusCode *ProxyAuthenticationRequired __attribute__((swift_name("ProxyAuthenticationRequired")));
@property (readonly) WVMKtor_httpHttpStatusCode *RequestHeaderFieldTooLarge __attribute__((swift_name("RequestHeaderFieldTooLarge")));
@property (readonly) WVMKtor_httpHttpStatusCode *RequestTimeout __attribute__((swift_name("RequestTimeout")));
@property (readonly) WVMKtor_httpHttpStatusCode *RequestURITooLong __attribute__((swift_name("RequestURITooLong")));
@property (readonly) WVMKtor_httpHttpStatusCode *RequestedRangeNotSatisfiable __attribute__((swift_name("RequestedRangeNotSatisfiable")));
@property (readonly) WVMKtor_httpHttpStatusCode *ResetContent __attribute__((swift_name("ResetContent")));
@property (readonly) WVMKtor_httpHttpStatusCode *SeeOther __attribute__((swift_name("SeeOther")));
@property (readonly) WVMKtor_httpHttpStatusCode *ServiceUnavailable __attribute__((swift_name("ServiceUnavailable")));
@property (readonly) WVMKtor_httpHttpStatusCode *SwitchProxy __attribute__((swift_name("SwitchProxy")));
@property (readonly) WVMKtor_httpHttpStatusCode *SwitchingProtocols __attribute__((swift_name("SwitchingProtocols")));
@property (readonly) WVMKtor_httpHttpStatusCode *TemporaryRedirect __attribute__((swift_name("TemporaryRedirect")));
@property (readonly) WVMKtor_httpHttpStatusCode *TooEarly __attribute__((swift_name("TooEarly")));
@property (readonly) WVMKtor_httpHttpStatusCode *TooManyRequests __attribute__((swift_name("TooManyRequests")));
@property (readonly) WVMKtor_httpHttpStatusCode *Unauthorized __attribute__((swift_name("Unauthorized")));
@property (readonly) WVMKtor_httpHttpStatusCode *UnprocessableEntity __attribute__((swift_name("UnprocessableEntity")));
@property (readonly) WVMKtor_httpHttpStatusCode *UnsupportedMediaType __attribute__((swift_name("UnsupportedMediaType")));
@property (readonly) WVMKtor_httpHttpStatusCode *UpgradeRequired __attribute__((swift_name("UpgradeRequired")));
@property (readonly) WVMKtor_httpHttpStatusCode *UseProxy __attribute__((swift_name("UseProxy")));
@property (readonly) WVMKtor_httpHttpStatusCode *VariantAlsoNegotiates __attribute__((swift_name("VariantAlsoNegotiates")));
@property (readonly) WVMKtor_httpHttpStatusCode *VersionNotSupported __attribute__((swift_name("VersionNotSupported")));
@property (readonly) NSArray<WVMKtor_httpHttpStatusCode *> *allStatusCodes __attribute__((swift_name("allStatusCodes")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsGMTDate.Companion")))
@interface WVMKtor_utilsGMTDateCompanion : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKtor_utilsGMTDateCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) WVMKtor_utilsGMTDate *START __attribute__((swift_name("START")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsWeekDay")))
@interface WVMKtor_utilsWeekDay : WVMKotlinEnum<WVMKtor_utilsWeekDay *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) WVMKtor_utilsWeekDayCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) WVMKtor_utilsWeekDay *monday __attribute__((swift_name("monday")));
@property (class, readonly) WVMKtor_utilsWeekDay *tuesday __attribute__((swift_name("tuesday")));
@property (class, readonly) WVMKtor_utilsWeekDay *wednesday __attribute__((swift_name("wednesday")));
@property (class, readonly) WVMKtor_utilsWeekDay *thursday __attribute__((swift_name("thursday")));
@property (class, readonly) WVMKtor_utilsWeekDay *friday __attribute__((swift_name("friday")));
@property (class, readonly) WVMKtor_utilsWeekDay *saturday __attribute__((swift_name("saturday")));
@property (class, readonly) WVMKtor_utilsWeekDay *sunday __attribute__((swift_name("sunday")));
+ (WVMKotlinArray<WVMKtor_utilsWeekDay *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsMonth")))
@interface WVMKtor_utilsMonth : WVMKotlinEnum<WVMKtor_utilsMonth *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) WVMKtor_utilsMonthCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) WVMKtor_utilsMonth *january __attribute__((swift_name("january")));
@property (class, readonly) WVMKtor_utilsMonth *february __attribute__((swift_name("february")));
@property (class, readonly) WVMKtor_utilsMonth *march __attribute__((swift_name("march")));
@property (class, readonly) WVMKtor_utilsMonth *april __attribute__((swift_name("april")));
@property (class, readonly) WVMKtor_utilsMonth *may __attribute__((swift_name("may")));
@property (class, readonly) WVMKtor_utilsMonth *june __attribute__((swift_name("june")));
@property (class, readonly) WVMKtor_utilsMonth *july __attribute__((swift_name("july")));
@property (class, readonly) WVMKtor_utilsMonth *august __attribute__((swift_name("august")));
@property (class, readonly) WVMKtor_utilsMonth *september __attribute__((swift_name("september")));
@property (class, readonly) WVMKtor_utilsMonth *october __attribute__((swift_name("october")));
@property (class, readonly) WVMKtor_utilsMonth *november __attribute__((swift_name("november")));
@property (class, readonly) WVMKtor_utilsMonth *december __attribute__((swift_name("december")));
+ (WVMKotlinArray<WVMKtor_utilsMonth *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpProtocolVersion.Companion")))
@interface WVMKtor_httpHttpProtocolVersionCompanion : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKtor_httpHttpProtocolVersionCompanion *shared __attribute__((swift_name("shared")));
- (WVMKtor_httpHttpProtocolVersion *)fromValueName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("fromValue(name:major:minor:)")));
- (WVMKtor_httpHttpProtocolVersion *)parseValue:(id)value __attribute__((swift_name("parse(value:)")));
@property (readonly) WVMKtor_httpHttpProtocolVersion *HTTP_1_0 __attribute__((swift_name("HTTP_1_0")));
@property (readonly) WVMKtor_httpHttpProtocolVersion *HTTP_1_1 __attribute__((swift_name("HTTP_1_1")));
@property (readonly) WVMKtor_httpHttpProtocolVersion *HTTP_2_0 __attribute__((swift_name("HTTP_2_0")));
@property (readonly) WVMKtor_httpHttpProtocolVersion *QUIC __attribute__((swift_name("QUIC")));
@property (readonly) WVMKtor_httpHttpProtocolVersion *SPDY_3 __attribute__((swift_name("SPDY_3")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioMemory")))
@interface WVMKtor_ioMemory : WVMBase
- (instancetype)initWithPointer:(void *)pointer size:(int64_t)size __attribute__((swift_name("init(pointer:size:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) WVMKtor_ioMemoryCompanion *companion __attribute__((swift_name("companion")));
- (void)doCopyToDestination:(WVMKtor_ioMemory *)destination offset:(int32_t)offset length:(int32_t)length destinationOffset:(int32_t)destinationOffset __attribute__((swift_name("doCopyTo(destination:offset:length:destinationOffset:)")));
- (void)doCopyToDestination:(WVMKtor_ioMemory *)destination offset:(int64_t)offset length:(int64_t)length destinationOffset_:(int64_t)destinationOffset __attribute__((swift_name("doCopyTo(destination:offset:length:destinationOffset_:)")));
- (int8_t)loadAtIndex:(int32_t)index __attribute__((swift_name("loadAt(index:)")));
- (int8_t)loadAtIndex_:(int64_t)index __attribute__((swift_name("loadAt(index_:)")));
- (WVMKtor_ioMemory *)sliceOffset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("slice(offset:length:)")));
- (WVMKtor_ioMemory *)sliceOffset:(int64_t)offset length_:(int64_t)length __attribute__((swift_name("slice(offset:length_:)")));
- (void)storeAtIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("storeAt(index:value:)")));
- (void)storeAtIndex:(int64_t)index value_:(int8_t)value __attribute__((swift_name("storeAt(index:value_:)")));
@property (readonly) void *pointer __attribute__((swift_name("pointer")));
@property (readonly) int64_t size __attribute__((swift_name("size")));
@property (readonly) int32_t size32 __attribute__((swift_name("size32")));
@end

__attribute__((swift_name("Ktor_ioBuffer")))
@interface WVMKtor_ioBuffer : WVMBase
- (instancetype)initWithMemory:(WVMKtor_ioMemory *)memory __attribute__((swift_name("init(memory:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("\n    We're migrating to the new kotlinx-io library.\n    This declaration is deprecated and will be removed in Ktor 4.0.0\n    If you have any problems with migration, please contact us in \n    https://youtrack.jetbrains.com/issue/KTOR-6030/Migrate-to-new-kotlinx.io-library\n    ")));
@property (class, readonly, getter=companion) WVMKtor_ioBufferCompanion *companion __attribute__((swift_name("companion")));
- (void)commitWrittenCount:(int32_t)count __attribute__((swift_name("commitWritten(count:)")));
- (void)discardExactCount:(int32_t)count __attribute__((swift_name("discardExact(count:)")));
- (WVMKtor_ioBuffer *)duplicate __attribute__((swift_name("duplicate()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)duplicateToCopy:(WVMKtor_ioBuffer *)copy __attribute__((swift_name("duplicateTo(copy:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (void)reserveEndGapEndGap:(int32_t)endGap __attribute__((swift_name("reserveEndGap(endGap:)")));
- (void)reserveStartGapStartGap:(int32_t)startGap __attribute__((swift_name("reserveStartGap(startGap:)")));
- (void)reset __attribute__((swift_name("reset()")));
- (void)resetForRead __attribute__((swift_name("resetForRead()")));
- (void)resetForWrite __attribute__((swift_name("resetForWrite()")));
- (void)resetForWriteLimit:(int32_t)limit __attribute__((swift_name("resetForWrite(limit:)")));
- (void)rewindCount:(int32_t)count __attribute__((swift_name("rewind(count:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (int32_t)tryPeekByte __attribute__((swift_name("tryPeekByte()")));
- (int32_t)tryReadByte __attribute__((swift_name("tryReadByte()")));
- (void)writeByteValue:(int8_t)value __attribute__((swift_name("writeByte(value:)")));
@property (readonly) int32_t capacity __attribute__((swift_name("capacity")));
@property (readonly) int32_t endGap __attribute__((swift_name("endGap")));
@property (readonly) int32_t limit __attribute__((swift_name("limit")));
@property (readonly) WVMKtor_ioMemory *memory __attribute__((swift_name("memory")));
@property (readonly) int32_t readPosition __attribute__((swift_name("readPosition")));
@property (readonly) int32_t readRemaining __attribute__((swift_name("readRemaining")));
@property (readonly) int32_t startGap __attribute__((swift_name("startGap")));
@property (readonly) int32_t writePosition __attribute__((swift_name("writePosition")));
@property (readonly) int32_t writeRemaining __attribute__((swift_name("writeRemaining")));
@end

__attribute__((swift_name("Ktor_ioChunkBuffer")))
@interface WVMKtor_ioChunkBuffer : WVMKtor_ioBuffer
- (instancetype)initWithMemory:(WVMKtor_ioMemory *)memory origin:(WVMKtor_ioChunkBuffer * _Nullable)origin parentPool:(id<WVMKtor_ioObjectPool> _Nullable)parentPool __attribute__((swift_name("init(memory:origin:parentPool:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("\n    We're migrating to the new kotlinx-io library.\n    This declaration is deprecated and will be removed in Ktor 4.0.0\n    If you have any problems with migration, please contact us in \n    https://youtrack.jetbrains.com/issue/KTOR-6030/Migrate-to-new-kotlinx.io-library\n    ")));
- (instancetype)initWithMemory:(WVMKtor_ioMemory *)memory __attribute__((swift_name("init(memory:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) WVMKtor_ioChunkBufferCompanion *companion __attribute__((swift_name("companion")));
- (WVMKtor_ioChunkBuffer * _Nullable)cleanNext __attribute__((swift_name("cleanNext()")));
- (WVMKtor_ioChunkBuffer *)duplicate __attribute__((swift_name("duplicate()")));
- (void)releasePool:(id<WVMKtor_ioObjectPool>)pool __attribute__((swift_name("release(pool:)")));
- (void)reset __attribute__((swift_name("reset()")));
@property (getter=next_) WVMKtor_ioChunkBuffer * _Nullable next __attribute__((swift_name("next")));
@property (readonly) WVMKtor_ioChunkBuffer * _Nullable origin __attribute__((swift_name("origin")));
@property (readonly) int32_t referenceCount __attribute__((swift_name("referenceCount")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface WVMKotlinByteArray : WVMBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(WVMByte *(^)(WVMInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (WVMKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("Ktor_ioInput")))
@interface WVMKtor_ioInput : WVMBase <WVMKtor_ioCloseable>
- (instancetype)initWithHead:(WVMKtor_ioChunkBuffer *)head remaining:(int64_t)remaining pool:(id<WVMKtor_ioObjectPool>)pool __attribute__((swift_name("init(head:remaining:pool:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("\n    We're migrating to the new kotlinx-io library.\n    This declaration is deprecated and will be removed in Ktor 4.0.0\n    If you have any problems with migration, please contact us in \n    https://youtrack.jetbrains.com/issue/KTOR-6030/Migrate-to-new-kotlinx.io-library\n    ")));
@property (class, readonly, getter=companion) WVMKtor_ioInputCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)canRead __attribute__((swift_name("canRead()")));
- (void)close __attribute__((swift_name("close()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)closeSource __attribute__((swift_name("closeSource()")));
- (int32_t)discardN:(int32_t)n __attribute__((swift_name("discard(n:)")));
- (int64_t)discardN_:(int64_t)n __attribute__((swift_name("discard(n_:)")));
- (void)discardExactN:(int32_t)n __attribute__((swift_name("discardExact(n:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (WVMKtor_ioChunkBuffer * _Nullable)fill __attribute__((swift_name("fill()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (int32_t)fillDestination:(WVMKtor_ioMemory *)destination offset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("fill(destination:offset:length:)")));
- (BOOL)hasBytesN:(int32_t)n __attribute__((swift_name("hasBytes(n:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)markNoMoreChunksAvailable __attribute__((swift_name("markNoMoreChunksAvailable()")));
- (int32_t)peekToBuffer:(WVMKtor_ioChunkBuffer *)buffer __attribute__((swift_name("peekTo(buffer:)")));
- (int64_t)peekToDestination:(WVMKtor_ioMemory *)destination destinationOffset:(int64_t)destinationOffset offset:(int64_t)offset min:(int64_t)min max:(int64_t)max __attribute__((swift_name("peekTo(destination:destinationOffset:offset:min:max:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (NSString *)readTextMin:(int32_t)min max:(int32_t)max __attribute__((swift_name("readText(min:max:)")));
- (int32_t)readTextOut:(id<WVMKotlinAppendable>)out min:(int32_t)min max:(int32_t)max __attribute__((swift_name("readText(out:min:max:)")));
- (NSString *)readTextExactExactCharacters:(int32_t)exactCharacters __attribute__((swift_name("readTextExact(exactCharacters:)")));
- (void)readTextExactOut:(id<WVMKotlinAppendable>)out exactCharacters:(int32_t)exactCharacters __attribute__((swift_name("readTextExact(out:exactCharacters:)")));
- (void)release_ __attribute__((swift_name("release()")));
- (int32_t)tryPeek __attribute__((swift_name("tryPeek()")));
@property (readonly) BOOL endOfInput __attribute__((swift_name("endOfInput")));
@property (readonly) id<WVMKtor_ioObjectPool> pool __attribute__((swift_name("pool")));
@property (readonly) int64_t remaining __attribute__((swift_name("remaining")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioByteReadPacket")))
@interface WVMKtor_ioByteReadPacket : WVMKtor_ioInput
- (instancetype)initWithHead:(WVMKtor_ioChunkBuffer *)head pool:(id<WVMKtor_ioObjectPool>)pool __attribute__((swift_name("init(head:pool:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithHead:(WVMKtor_ioChunkBuffer *)head remaining:(int64_t)remaining pool:(id<WVMKtor_ioObjectPool>)pool __attribute__((swift_name("init(head:remaining:pool:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) WVMKtor_ioByteReadPacketCompanion *companion __attribute__((swift_name("companion")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)closeSource __attribute__((swift_name("closeSource()")));
- (WVMKtor_ioByteReadPacket *)doCopy __attribute__((swift_name("doCopy()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (WVMKtor_ioChunkBuffer * _Nullable)fill __attribute__((swift_name("fill()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (int32_t)fillDestination:(WVMKtor_ioMemory *)destination offset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("fill(destination:offset:length:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Ktor_ioReadSession")))
@protocol WVMKtor_ioReadSession
@required
- (int32_t)discardN:(int32_t)n __attribute__((swift_name("discard(n:)")));
- (WVMKtor_ioChunkBuffer * _Nullable)requestAtLeast:(int32_t)atLeast __attribute__((swift_name("request(atLeast:)")));
@property (readonly) int32_t availableForRead __attribute__((swift_name("availableForRead")));
@end

__attribute__((swift_name("KotlinSuspendFunction1")))
@protocol WVMKotlinSuspendFunction1 <WVMKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:completionHandler:)")));
@end

__attribute__((swift_name("KotlinAppendable")))
@protocol WVMKotlinAppendable
@required
- (id<WVMKotlinAppendable>)appendValue:(unichar)value __attribute__((swift_name("append(value:)")));
- (id<WVMKotlinAppendable>)appendValue_:(id _Nullable)value __attribute__((swift_name("append(value_:)")));
- (id<WVMKotlinAppendable>)appendValue:(id _Nullable)value startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("append(value:startIndex:endIndex:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLBuilder.Companion")))
@interface WVMKtor_httpURLBuilderCompanion : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKtor_httpURLBuilderCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Ktor_httpParametersBuilder")))
@protocol WVMKtor_httpParametersBuilder <WVMKtor_utilsStringValuesBuilder>
@required
@end

__attribute__((swift_name("KotlinKType")))
@protocol WVMKotlinKType
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
@property (readonly) NSArray<WVMKotlinKTypeProjection *> *arguments __attribute__((swift_name("arguments")));

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
@property (readonly) id<WVMKotlinKClassifier> _Nullable classifier __attribute__((swift_name("classifier")));
@property (readonly) BOOL isMarkedNullable __attribute__((swift_name("isMarkedNullable")));
@end

__attribute__((swift_name("Koin_coreKoinExtension")))
@protocol WVMKoin_coreKoinExtension
@required
- (void)onClose __attribute__((swift_name("onClose()")));
@property WVMKoin_coreKoin *koin __attribute__((swift_name("koin")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreScopeRegistry.Companion")))
@interface WVMKoin_coreScopeRegistryCompanion : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKoin_coreScopeRegistryCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol.Companion")))
@interface WVMKtor_httpURLProtocolCompanion : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKtor_httpURLProtocolCompanion *shared __attribute__((swift_name("shared")));
- (WVMKtor_httpURLProtocol *)createOrDefaultName:(NSString *)name __attribute__((swift_name("createOrDefault(name:)")));
@property (readonly) WVMKtor_httpURLProtocol *HTTP __attribute__((swift_name("HTTP")));
@property (readonly) WVMKtor_httpURLProtocol *HTTPS __attribute__((swift_name("HTTPS")));
@property (readonly) WVMKtor_httpURLProtocol *SOCKS __attribute__((swift_name("SOCKS")));
@property (readonly) WVMKtor_httpURLProtocol *WS __attribute__((swift_name("WS")));
@property (readonly) WVMKtor_httpURLProtocol *WSS __attribute__((swift_name("WSS")));
@property (readonly) NSDictionary<NSString *, WVMKtor_httpURLProtocol *> *byName __attribute__((swift_name("byName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeaderValueParam")))
@interface WVMKtor_httpHeaderValueParam : WVMBase
- (instancetype)initWithName:(NSString *)name value:(NSString *)value __attribute__((swift_name("init(name:value:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithName:(NSString *)name value:(NSString *)value escapeValue:(BOOL)escapeValue __attribute__((swift_name("init(name:value:escapeValue:)"))) __attribute__((objc_designated_initializer));
- (WVMKtor_httpHeaderValueParam *)doCopyName:(NSString *)name value:(NSString *)value escapeValue:(BOOL)escapeValue __attribute__((swift_name("doCopy(name:value:escapeValue:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL escapeValue __attribute__((swift_name("escapeValue")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeaderValueWithParameters.Companion")))
@interface WVMKtor_httpHeaderValueWithParametersCompanion : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKtor_httpHeaderValueWithParametersCompanion *shared __attribute__((swift_name("shared")));
- (id _Nullable)parseValue:(NSString *)value init:(id _Nullable (^)(NSString *, NSArray<WVMKtor_httpHeaderValueParam *> *))init __attribute__((swift_name("parse(value:init:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpContentType.Companion")))
@interface WVMKtor_httpContentTypeCompanion : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKtor_httpContentTypeCompanion *shared __attribute__((swift_name("shared")));
- (WVMKtor_httpContentType *)parseValue:(NSString *)value __attribute__((swift_name("parse(value:)")));
@property (readonly) WVMKtor_httpContentType *Any __attribute__((swift_name("Any")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsWeekDay.Companion")))
@interface WVMKtor_utilsWeekDayCompanion : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKtor_utilsWeekDayCompanion *shared __attribute__((swift_name("shared")));
- (WVMKtor_utilsWeekDay *)fromOrdinal:(int32_t)ordinal __attribute__((swift_name("from(ordinal:)")));
- (WVMKtor_utilsWeekDay *)fromValue:(NSString *)value __attribute__((swift_name("from(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsMonth.Companion")))
@interface WVMKtor_utilsMonthCompanion : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKtor_utilsMonthCompanion *shared __attribute__((swift_name("shared")));
- (WVMKtor_utilsMonth *)fromOrdinal:(int32_t)ordinal __attribute__((swift_name("from(ordinal:)")));
- (WVMKtor_utilsMonth *)fromValue:(NSString *)value __attribute__((swift_name("from(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioMemory.Companion")))
@interface WVMKtor_ioMemoryCompanion : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKtor_ioMemoryCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) WVMKtor_ioMemory *Empty __attribute__((swift_name("Empty")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioBuffer.Companion")))
@interface WVMKtor_ioBufferCompanion : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKtor_ioBufferCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) WVMKtor_ioBuffer *Empty __attribute__((swift_name("Empty")));
@property (readonly) int32_t ReservedSize __attribute__((swift_name("ReservedSize")));
@end

__attribute__((swift_name("Ktor_ioObjectPool")))
@protocol WVMKtor_ioObjectPool <WVMKtor_ioCloseable>
@required
- (id)borrow __attribute__((swift_name("borrow()")));
- (void)dispose __attribute__((swift_name("dispose()")));
- (void)recycleInstance:(id)instance __attribute__((swift_name("recycle(instance:)")));
@property (readonly) int32_t capacity __attribute__((swift_name("capacity")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioChunkBuffer.Companion")))
@interface WVMKtor_ioChunkBufferCompanion : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKtor_ioChunkBufferCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) WVMKtor_ioChunkBuffer *Empty __attribute__((swift_name("Empty")));
@property (readonly) id<WVMKtor_ioObjectPool> EmptyPool __attribute__((swift_name("EmptyPool")));
@property (readonly) id<WVMKtor_ioObjectPool> Pool __attribute__((swift_name("Pool")));
@end

__attribute__((swift_name("KotlinByteIterator")))
@interface WVMKotlinByteIterator : WVMBase <WVMKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (WVMByte *)next __attribute__((swift_name("next()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioInput.Companion")))
@interface WVMKtor_ioInputCompanion : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKtor_ioInputCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioByteReadPacket.Companion")))
@interface WVMKtor_ioByteReadPacketCompanion : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKtor_ioByteReadPacketCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) WVMKtor_ioByteReadPacket *Empty __attribute__((swift_name("Empty")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKTypeProjection")))
@interface WVMKotlinKTypeProjection : WVMBase
- (instancetype)initWithVariance:(WVMKotlinKVariance * _Nullable)variance type:(id<WVMKotlinKType> _Nullable)type __attribute__((swift_name("init(variance:type:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) WVMKotlinKTypeProjectionCompanion *companion __attribute__((swift_name("companion")));
- (WVMKotlinKTypeProjection *)doCopyVariance:(WVMKotlinKVariance * _Nullable)variance type:(id<WVMKotlinKType> _Nullable)type __attribute__((swift_name("doCopy(variance:type:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<WVMKotlinKType> _Nullable type __attribute__((swift_name("type")));
@property (readonly) WVMKotlinKVariance * _Nullable variance __attribute__((swift_name("variance")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKVariance")))
@interface WVMKotlinKVariance : WVMKotlinEnum<WVMKotlinKVariance *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) WVMKotlinKVariance *invariant __attribute__((swift_name("invariant")));
@property (class, readonly) WVMKotlinKVariance *in __attribute__((swift_name("in")));
@property (class, readonly) WVMKotlinKVariance *out __attribute__((swift_name("out")));
+ (WVMKotlinArray<WVMKotlinKVariance *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<WVMKotlinKVariance *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKTypeProjection.Companion")))
@interface WVMKotlinKTypeProjectionCompanion : WVMBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) WVMKotlinKTypeProjectionCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (WVMKotlinKTypeProjection *)contravariantType:(id<WVMKotlinKType>)type __attribute__((swift_name("contravariant(type:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (WVMKotlinKTypeProjection *)covariantType:(id<WVMKotlinKType>)type __attribute__((swift_name("covariant(type:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (WVMKotlinKTypeProjection *)invariantType:(id<WVMKotlinKType>)type __attribute__((swift_name("invariant(type:)")));
@property (readonly) WVMKotlinKTypeProjection *STAR __attribute__((swift_name("STAR")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
